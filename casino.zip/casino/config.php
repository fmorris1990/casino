<?php
declare(strict_types=1);

// === DB SETTINGS (cPanel MySQL) ===
const DB_HOST = 'localhost';
const DB_NAME = 'fdcsjyxq_casino';
const DB_USER = 'fdcsjyxq_casino';
const DB_PASS = 'casINO123#@!';
const DB_CHARSET = 'utf8mb4';

// === SMTP Setting === //
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'mail.fm3holdings.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // tls or ssl
define('SMTP_USERNAME', 'no-reply@fm3holdings.com');
define('SMTP_PASSWORD', '4Tr1bunal!4Tr1bunal!');
define('SMTP_FROM_EMAIL', 'no-reply@fm3holdings.com');
define('SMTP_FROM_NAME', 'FM3 Holdings Casino');

// === APP SETTINGS ===
const APP_NAME = 'Casino Room';

// === EMAIL 2FA SETTINGS ===
const MAIL_FROM = 'no-reply@fm3holdings.com'; // Must exist on your domain for best deliverability
const OTP_TTL_SECONDS = 300; // 5 minutes

// === SESSION ===
const SESSION_COOKIE_NAME = 'casino_sid';