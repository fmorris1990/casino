<?php
declare(strict_types=1);
require __DIR__ . '/common.php'; // requires login
$csrf = $_SESSION['csrf'];
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Baccarat</title>
  <link rel="stylesheet" href="style.css"/>
  <style>
    .grid2{ display:grid; grid-template-columns: 1.1fr .9fr; gap:14px; }
    @media (max-width: 980px){ .grid2{ grid-template-columns: 1fr; } }

    .betgrid{
      display:grid;
      grid-template-columns: repeat(3, minmax(0,1fr));
      gap:10px;
    }
    @media (max-width: 720px){ .betgrid{ grid-template-columns: 1fr; } }

    .betbox{
      border:1px solid rgba(255,255,255,.10);
      background: rgba(0,0,0,.12);
      border-radius:16px;
      padding:12px;
    }
    .betbox h3{ margin:0; font-size:14px; letter-spacing:.2px; }
    .betbox .small{ opacity:.88; margin-top:6px; line-height:1.45; }

    .inp{
      width:100%;
      margin-top:10px;
      height:38px;
      border-radius:12px;
      border:1px solid rgba(255,255,255,.14);
      background: rgba(0,0,0,.18);
      color: #fff;
      padding:0 12px;
      outline:none;
    }
    .inp:focus{ border-color: rgba(120,220,255,.35); box-shadow: 0 0 0 3px rgba(120,220,255,.12); }

    .cards{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; padding-top:6px; }
    .cardFace{
      width:64px; height:88px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.14);
      background: linear-gradient(180deg, rgba(255,255,255,.12), rgba(0,0,0,.18));
      box-shadow: 0 10px 26px rgba(0,0,0,.25);
      position:relative;
      overflow:hidden;
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      padding:8px;
    }
    .cardFace::after{
      content:'';
      position:absolute; inset:0;
      background: radial-gradient(circle at 30% 30%, rgba(120,220,255,.16), transparent 50%),
                  radial-gradient(circle at 70% 80%, rgba(255,120,220,.12), transparent 55%);
      pointer-events:none;
    }
    .rank{ position:relative; z-index:2; font-weight:950; font-size:16px; line-height:1; }
    .suit{ position:relative; z-index:2; font-size:18px; }
    .pip{
      position:absolute; left:50%; top:50%;
      transform: translate(-50%,-50%);
      font-size:28px;
      opacity:.28;
      z-index:1;
      filter: blur(.2px);
    }
    .red{ color:#ff6b6b; }
    .black{ color:#eaeaea; }

    .pillrow .pill{ white-space:nowrap; }

    .outcomeTag{
      display:inline-flex; align-items:center; gap:8px;
      padding:6px 10px;
      border-radius:999px;
      border:1px solid rgba(255,255,255,.12);
      background: rgba(255,255,255,.06);
      font-size:12px;
      opacity:.95;
    }
    .tagWin{ border-color: rgba(80,220,140,.25); background: rgba(80,220,140,.10); }
    .tagTie{ border-color: rgba(120,220,255,.25); background: rgba(120,220,255,.10); }
    .tagLose{ border-color: rgba(255,120,120,.22); background: rgba(255,120,120,.10); }

    .sideHits{ display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
    .sideHits .chip{
      display:inline-flex; align-items:center; gap:8px;
      padding:6px 10px;
      border-radius:999px;
      border:1px solid rgba(255,255,255,.12);
      background: rgba(255,255,255,.05);
      font-size:12px;
      opacity:.95;
    }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🎴 Baccarat</h1>
        <div class="sub">Casino-style baccarat with main bets + side bets. Baccarat always uses an 8-deck shoe.</div>
      </div>
      <div class="nav">
        <a class="btn" href="casino.php">🏠 Hub</a>
        <a class="btn" href="lottery.php">🎰 Slots</a>
        <a class="btn" href="blackjack.php">🂡 Blackjack</a>
        <a class="btn active" href="baccarat.php">🎴 Baccarat</a>
        <a class="btn" href="tutorial.php">🎓 Tutorial</a>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="pillrow" style="margin-top:12px;">
      <div class="pill">Credits: <strong id="m-credits">—</strong></div>
      <div class="pill">Session high: <strong id="m-high">—</strong></div>
      <div class="pill">Baccarat shoe: <strong id="m-shoe">—</strong></div>
    </div>
  </div>

  <div class="grid2" style="margin-top:14px;">
    <!-- LEFT: Gameplay -->
    <div class="card">
      <h2 style="margin:0; font-size:18px;">Place Bets</h2>
      <div class="sub">Main bets pay: Player 1:1 • Banker 0.95:1 • Tie 8:1. Side bets: Pairs 11:1 • Perfect Pair 25:1.</div>

      <div id="msg" class="msg" style="margin-top:12px;"></div>

      <div class="betgrid" style="margin-top:12px;">
        <div class="betbox">
          <h3>Player</h3>
          <div class="small">Pays <b>1:1</b> when Player wins.</div>
          <input id="bet-player" class="inp" type="number" min="0" step="1" value="0" />
        </div>

        <div class="betbox">
          <h3>Banker</h3>
          <div class="small">Pays <b>0.95:1</b> (5% commission) when Banker wins.</div>
          <input id="bet-banker" class="inp" type="number" min="0" step="1" value="0" />
        </div>

        <div class="betbox">
          <h3>Tie</h3>
          <div class="small">Pays <b>8:1</b> (total return 9× including stake).</div>
          <input id="bet-tie" class="inp" type="number" min="0" step="1" value="0" />
        </div>
      </div>

      <h2 style="margin:14px 0 0; font-size:18px;">Side Bets</h2>
      <div class="sub">Side bets are based on the <b>first two cards</b> of Player/Banker.</div>

      <div class="betgrid" style="margin-top:12px;">
        <div class="betbox">
          <h3>Player Pair</h3>
          <div class="small">First two Player cards same rank. Pays <b>11:1</b>.</div>
          <input id="bet-playerPair" class="inp" type="number" min="0" step="1" value="0" />
        </div>

        <div class="betbox">
          <h3>Banker Pair</h3>
          <div class="small">First two Banker cards same rank. Pays <b>11:1</b>.</div>
          <input id="bet-bankerPair" class="inp" type="number" min="0" step="1" value="0" />
        </div>

        <div class="betbox">
          <h3>Perfect Pair</h3>
          <div class="small">Suited pair on Player or Banker. Pays <b>25:1</b>.</div>
          <input id="bet-perfectPair" class="inp" type="number" min="0" step="1" value="0" />
        </div>
      </div>

      <div class="actions" style="margin-top:14px;">
        <button class="btn" onclick="deal()">🂠 Deal</button>
        <button class="btn secondary" onclick="resetRound()">Reset Round</button>
      </div>

      <div class="box" style="margin-top:14px;">
        <div class="small"><b>Result</b></div>
        <div id="resultLine" class="small" style="margin-top:8px;">—</div>

        <div class="sideHits" id="sideHits"></div>

        <div class="grid" style="margin-top:12px;">
          <div class="box">
            <div class="small"><b>Player</b> • Total: <b id="p-total">—</b></div>
            <div class="cards" id="p-cards" style="margin-top:8px;"></div>
          </div>
          <div class="box">
            <div class="small"><b>Banker</b> • Total: <b id="b-total">—</b></div>
            <div class="cards" id="b-cards" style="margin-top:8px;"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT: History -->
    <div class="card">
      <h2 style="margin:0; font-size:18px;">History</h2>
      <div class="sub">Previous hands (this session).</div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>Recent Hands</b></div>
        <div class="hist" id="hist" style="margin-top:10px;"></div>
      </div>
    </div>
  </div>
</div>

<script>
const CSRF = <?php echo json_encode($csrf); ?>;

async function api(op, payload={}){
  const res = await fetch('api.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({op, csrf: CSRF, ...payload})
  });
  const data = await res.json();
  if(!res.ok || !data.ok) throw new Error(data?.error || 'Request failed');
  return data;
}

function money(n){ return String(Math.floor(Number(n||0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function setMsg(type, text){
  document.getElementById('msg').innerHTML = text ? `<div class="${type==='err'?'err':'ok'}">${text}</div>` : '';
}

function renderMeta(m){
  document.getElementById('m-credits').textContent = money(m.credits);
  document.getElementById('m-high').textContent = money(m.sessionHighCredits ?? m.credits);

  // baccarat uses its own shoe info in bac_snapshot()
  // we'll set this from bac payload too, but keep meta stable
}

function suitClass(s){
  return (s==='♥' || s==='♦') ? 'red' : 'black';
}

function cardFace(c){
  if(!c) return '';
  const r = c.r ?? '';
  const s = c.s ?? '';
  const cls = suitClass(s);
  return `
    <div class="cardFace ${cls}">
      <div class="rank">${r}</div>
      <div class="suit">${s}</div>
      <div class="pip">${s}</div>
    </div>
  `;
}

function renderCards(elId, cards){
  const el = document.getElementById(elId);
  if(!Array.isArray(cards) || !cards.length){
    el.innerHTML = `<div class="small" style="opacity:.85;">—</div>`;
    return;
  }
  el.innerHTML = cards.map(cardFace).join('');
}

function renderShoeFromBac(bac){
  const s = bac?.shoe;
  if(!s){ document.getElementById('m-shoe').textContent = '8 decks'; return; }
  document.getElementById('m-shoe').textContent = `${s.remaining}/${s.totalCards} left • shuffles ${s.shuffles} • 8 decks`;
}

function outcomeTag(outcome, label){
  let cls='outcomeTag';
  if(outcome==='player' || outcome==='banker') cls += ' tagWin';
  if(outcome==='tie') cls += ' tagTie';
  return `<span class="${cls}">${label}</span>`;
}

function renderSideHits(side){
  const el = document.getElementById('sideHits');
  if(!side){ el.innerHTML = ''; return; }
  const chips = [];
  if(side.playerPair) chips.push(`<span class="chip">✅ Player Pair</span>`);
  if(side.bankerPair) chips.push(`<span class="chip">✅ Banker Pair</span>`);
  if(side.perfectPair) chips.push(`<span class="chip">🏆 Perfect Pair</span>`);
  el.innerHTML = chips.length ? chips.join('') : `<span class="chip" style="opacity:.8;">No side-bet hits</span>`;
}

function renderBac(bac){
  document.getElementById('p-total').textContent = bac.playerTotal ?? '—';
  document.getElementById('b-total').textContent = bac.bankerTotal ?? '—';

  renderCards('p-cards', bac.player || []);
  renderCards('b-cards', bac.banker || []);

  renderShoeFromBac(bac);

  const res = bac.result;
  if(!res){
    document.getElementById('resultLine').innerHTML = '—';
    renderSideHits(null);
    return;
  }

  const nat = res.natural ? ` <span class="outcomeTag">Natural</span>` : '';
  const out = res.outcome || 'tie';
  const label = res.label || '—';

  document.getElementById('resultLine').innerHTML =
    `${outcomeTag(out, label)}${nat}
     <span class="small" style="opacity:.9;"> • ${res.payoutLabel || ''}</span>`;

  renderSideHits(res.side || null);
}

function renderHistory(items){
  const el = document.getElementById('hist');
  if(!Array.isArray(items) || !items.length){
    el.innerHTML = `<div class="histitem">No hands yet.</div>`;
    return;
  }

  el.innerHTML = items.map(it=>{
    const o = it.outcome || 'tie';
    const lbl = it.label || '';
    const pt = it.playerTotal ?? '';
    const bt = it.bankerTotal ?? '';
    return `
      <div class="histitem">
        <div><b>${lbl}</b> <span class="small">• ${it.time}</span></div>
        <div class="small">Outcome: ${o} • Totals P:${pt} / B:${bt}</div>
      </div>
    `;
  }).join('');
}

function readBets(){
  const v = (id)=> Math.max(0, parseInt(document.getElementById(id).value || '0', 10) || 0);
  return {
    player: v('bet-player'),
    banker: v('bet-banker'),
    tie: v('bet-tie'),
    playerPair: v('bet-playerPair'),
    bankerPair: v('bet-bankerPair'),
    perfectPair: v('bet-perfectPair'),
  };
}

async function load(){
  setMsg('', '');
  const d = await api('bac_get');
  renderMeta(d.meta);
  renderBac(d.bac);
  renderHistory(d.bac.history || []);
}

async function resetRound(){
  setMsg('', '');
  try{
    const d = await api('bac_reset');
    renderMeta(d.meta);
    renderBac(d.bac);
    renderHistory(d.bac.history || []);
    setMsg('ok', 'Round reset.');
  } catch(e){
    setMsg('err', e.message);
  }
}

async function deal(){
  setMsg('', '');
  try{
    const bet = readBets();
    const d = await api('bac_deal', {bet});
    renderMeta(d.meta);
    renderBac(d.bac);
    renderHistory(d.bac.history || []);
    setMsg('ok', 'Deal complete.');
  } catch(e){
    setMsg('err', e.message);
  }
}

load().catch(e=>setMsg('err', e.message));
</script>
</body>
</html>
