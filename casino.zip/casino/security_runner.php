<?php
declare(strict_types=1);

require __DIR__ . '/security_admin_guard.php';
require __DIR__ . '/security_checks.php';

header('Content-Type: application/json; charset=utf-8');

try {
  $env = php_env_checks();
  $headers = security_header_checks();
  $ports = local_listening_ports();
  $paths = app_path_safety();

  echo json_encode([
    'ok' => true,
    'env' => $env,
    'headers' => $headers,
    'ports' => $ports,
    'paths' => $paths,
    'time' => date('c'),
  ], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_SLASHES);
}
