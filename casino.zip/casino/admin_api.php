<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

require_admin();
header('Content-Type: application/json; charset=utf-8');

function out(int $code, array $p): void {
  http_response_code($code);
  echo json_encode($p, JSON_UNESCAPED_SLASHES);
  exit;
}

$raw = file_get_contents('php://input');
$data = json_decode((string)$raw, true);
if (!is_array($data)) $data = [];

try {
  csrf_check($data['csrf'] ?? null);
  $op = (string)($data['op'] ?? '');

  $pdo = db();
  $me = current_user();
  $meId = (int)($me['id'] ?? 0);

  $fetchUsers = function(string $q='') use ($pdo): array {
    $q = trim($q);
    if ($q !== '') {
      $like = '%'.$q.'%';
      $st = $pdo->prepare("SELECT id,email,phone,is_admin,is_banned,credits,total_wagered,total_won FROM users
                           WHERE email LIKE ? OR phone LIKE ? ORDER BY id DESC LIMIT 200");
      $st->execute([$like,$like]);
      return $st->fetchAll();
    }
    $st = $pdo->query("SELECT id,email,phone,is_admin,is_banned,credits,total_wagered,total_won FROM users ORDER BY id DESC LIMIT 200");
    return $st->fetchAll();
  };

  if ($op === 'users_list') {
    out(200, ['ok'=>true,'users'=>$fetchUsers((string)($data['q'] ?? ''))]);
  }

  if ($op === 'user_credit_add') {
    $uid = (int)($data['userId'] ?? 0);
    $amt = (int)($data['amt'] ?? 0);
    if ($uid<=0 || $amt<=0) throw new Exception("Invalid request.");

    $pdo->prepare("UPDATE users SET credits = credits + ? WHERE id=?")->execute([$amt, $uid]);
    $pdo->prepare("INSERT INTO audit_log (actor_user_id, action, target_user_id, detail) VALUES (?,?,?,?)")
        ->execute([$meId,'credit_add',$uid, json_encode(['amt'=>$amt])]);

    out(200, ['ok'=>true,'users'=>$fetchUsers((string)($data['q'] ?? ''))]);
  }

  if ($op === 'all_credit_add') {
    $amt = (int)($data['amt'] ?? 0);
    if ($amt<=0) throw new Exception("Invalid amount.");
    $pdo->prepare("UPDATE users SET credits = credits + ?")->execute([$amt]);
    $pdo->prepare("INSERT INTO audit_log (actor_user_id, action, detail) VALUES (?,?,?)")
        ->execute([$meId,'credit_add_all', json_encode(['amt'=>$amt])]);

    out(200, ['ok'=>true,'users'=>$fetchUsers((string)($data['q'] ?? ''))]);
  }

  if ($op === 'user_ban_set') {
    $uid = (int)($data['userId'] ?? 0);
    $ban = (bool)($data['banned'] ?? false);
    if ($uid<=0) throw new Exception("Invalid user.");
    $pdo->prepare("UPDATE users SET is_banned=? WHERE id=?")->execute([$ban?1:0, $uid]);
    $pdo->prepare("INSERT INTO audit_log (actor_user_id, action, target_user_id, detail) VALUES (?,?,?,?)")
        ->execute([$meId,'ban_set',$uid, json_encode(['banned'=>$ban])]);

    out(200, ['ok'=>true,'users'=>$fetchUsers((string)($data['q'] ?? ''))]);
  }

  if ($op === 'user_admin_set') {
    $uid = (int)($data['userId'] ?? 0);
    $isAdmin = (bool)($data['isAdmin'] ?? false);
    if ($uid<=0) throw new Exception("Invalid user.");
    if ($uid === $meId && $isAdmin === false) throw new Exception("You can't remove your own admin role here.");

    $pdo->prepare("UPDATE users SET is_admin=? WHERE id=?")->execute([$isAdmin?1:0, $uid]);
    $pdo->prepare("INSERT INTO audit_log (actor_user_id, action, target_user_id, detail) VALUES (?,?,?,?)")
        ->execute([$meId,'admin_set',$uid, json_encode(['is_admin'=>$isAdmin])]);

    out(200, ['ok'=>true,'users'=>$fetchUsers((string)($data['q'] ?? ''))]);
  }

  out(400, ['ok'=>false,'error'=>'Unknown op.']);

} catch (Throwable $e) {
  out(400, ['ok'=>false,'error'=>$e->getMessage()]);
}
