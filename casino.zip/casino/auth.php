<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/security.php';

/**
 * =========================
 *  Session / Security config
 * =========================
 */

// 20 minutes idle timeout
if (!defined('IDLE_TIMEOUT_SECONDS')) define('IDLE_TIMEOUT_SECONDS', 20 * 60);

// OTP TTL (login + reset)
if (!defined('OTP_TTL_SECONDS')) define('OTP_TTL_SECONDS', 10 * 60);

// App/email defaults
if (!defined('APP_NAME')) define('APP_NAME', 'FM3 Holdings');
if (!defined('MAIL_FROM')) define('MAIL_FROM', 'no-reply@fm3holdings.com');

// SMTP defaults (won't fatal if you didn't define them yet)
if (!defined('SMTP_ENABLED')) define('SMTP_ENABLED', false);
if (!defined('SMTP_HOST')) define('SMTP_HOST', '');
if (!defined('SMTP_PORT')) define('SMTP_PORT', 587);
if (!defined('SMTP_SECURE')) define('SMTP_SECURE', 'tls'); // tls|ssl|''
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', '');
if (!defined('SMTP_PASSWORD')) define('SMTP_PASSWORD', '');
if (!defined('SMTP_FROM_EMAIL')) define('SMTP_FROM_EMAIL', MAIL_FROM);
if (!defined('SMTP_FROM_NAME')) define('SMTP_FROM_NAME', APP_NAME . ' Casino');

/**
 * =========================
 *  Helpers
 * =========================
 */

function normalize_email_safe(string $email): string {
  // use normalize_email() if you already have it in security.php
  if (function_exists('normalize_email')) return normalize_email($email);
  return strtolower(trim($email));
}

function mail_send(string $toEmail, string $subject, string $bodyText): bool {
  $toEmail = trim($toEmail);
  if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) return false;

  // Prefer SMTP (PHPMailer) if enabled
  if (SMTP_ENABLED) {
    try {
      $base = __DIR__ . '/lib/PHPMailer/';
      $ex = $base . 'Exception.php';
      $pm = $base . 'PHPMailer.php';
      $sm = $base . 'SMTP.php';

      if (is_file($ex) && is_file($pm) && is_file($sm)) {
        require_once $ex;
        require_once $pm;
        require_once $sm;

        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->Port = (int)SMTP_PORT;

        $secure = trim((string)SMTP_SECURE);
        if ($secure !== '') $mail->SMTPSecure = $secure;

        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;

        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addReplyTo(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail);

        $mail->isHTML(false);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = $subject;
        $mail->Body = $bodyText;

        $mail->send();
        return true;
      } else {
        error_log("PHPMailer files missing in /casino/lib/PHPMailer/. Using mail() fallback.");
      }
    } catch (Throwable $e) {
      error_log("SMTP send failed: " . $e->getMessage());
      // continue to mail() fallback
    }
  }

  // Fallback to PHP mail()
  $headers = "From: " . MAIL_FROM . "\r\n";
  $headers .= "Reply-To: " . MAIL_FROM . "\r\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
  return @mail($toEmail, $subject, $bodyText, $headers);
}

function touch_activity(): void {
  session_boot();
  $_SESSION['last_activity'] = time();
}

function enforce_idle_timeout(): void {
  session_boot();
  $last = (int)($_SESSION['last_activity'] ?? 0);
  if ($last > 0 && (time() - $last) > IDLE_TIMEOUT_SECONDS) {
    logout_user(); // clears session + user_sessions row
    header('Location: login.php?timeout=1');
    exit;
  }
}

/**
 * =========================
 *  Auth primitives
 * =========================
 */

function current_user(): ?array {
  session_boot();
  enforce_idle_timeout();

  if (!isset($_SESSION['user_id'])) return null;

  $st = db()->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
  $st->execute([(int)$_SESSION['user_id']]);
  $u = $st->fetch();
  if (!$u) return null;

  // banned check here too (avoid access anywhere)
  if ((int)($u['is_banned'] ?? 0) === 1) return null;

  touch_activity();
  return $u;
}

function require_login(): array {
  $u = current_user();
  if (!$u) {
    header('Location: login.php');
    exit;
  }
  return $u;
}

function require_admin(): array {
  $u = require_login();
  if ((int)($u['is_admin'] ?? 0) !== 1) {
    http_response_code(403);
    echo "Admins only.";
    exit;
  }
  return $u;
}

function establish_session(int $userId): void {
  session_boot();
  session_regenerate_id(true);

  $_SESSION['user_id'] = $userId;
  touch_activity();

  // Track active sessions (requires table user_sessions(user_id, session_id))
  try {
    db()->prepare("INSERT INTO user_sessions (user_id, session_id) VALUES (?, ?)")
      ->execute([$userId, session_id()]);
  } catch (Throwable $e) {
    // don't break login if logging table isn't present
    error_log("user_sessions insert failed: " . $e->getMessage());
  }
}

function logout_user(): void {
  session_boot();
  $sid = session_id();

  try {
    db()->prepare("DELETE FROM user_sessions WHERE session_id=?")->execute([$sid]);
  } catch (Throwable $e) {
    // ignore
  }

  $_SESSION = [];
  if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
  }
  session_destroy();
}

function create_user(string $email, string $password, ?string $phone=null): int {
  $email = normalize_email_safe($email);
  $phone = $phone ? trim($phone) : null;

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new Exception("Invalid email.");
  if (strlen($password) < 10) throw new Exception("Password must be at least 10 characters.");

  $hash = password_hash($password, PASSWORD_ARGON2ID);
  if (!$hash) throw new Exception("Failed to hash password.");

  $pdo = db();
  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("INSERT INTO users (email, phone, password_hash) VALUES (?, ?, ?)");
    $st->execute([$email, $phone, $hash]);
    $uid = (int)$pdo->lastInsertId();

    // First user becomes admin if none exist
    $count = (int)$pdo->query("SELECT COUNT(*) AS c FROM users WHERE is_admin=1")->fetch()['c'];
    if ($count === 0) {
      $pdo->prepare("UPDATE users SET is_admin=1 WHERE id=?")->execute([$uid]);
    }

    $pdo->commit();
    return $uid;
  } catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
  }
}

function login_password(string $email, string $password): array {
  $email = normalize_email_safe($email);
  $pdo = db();
  $st = $pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $u = $st->fetch();

  if (!$u) throw new Exception("Invalid login.");
  if ((int)($u['is_banned'] ?? 0) === 1) throw new Exception("Account disabled.");

  if (!password_verify($password, (string)$u['password_hash'])) {
    throw new Exception("Invalid login.");
  }

  if (password_needs_rehash((string)$u['password_hash'], PASSWORD_ARGON2ID)) {
    $newHash = password_hash($password, PASSWORD_ARGON2ID);
    if ($newHash) {
      $pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$newHash, (int)$u['id']]);
      $u['password_hash'] = $newHash;
    }
  }

  return $u;
}

/**
 * =========================
 *  OTP (Login 2FA)
 * =========================
 */

function start_2fa_email(int $userId, string $email): void {
  $code = random_otp_code();
  $hash = password_hash($code, PASSWORD_DEFAULT);

  $expires = now()->modify('+' . OTP_TTL_SECONDS . ' seconds')->format('Y-m-d H:i:s');

  $pdo = db();

  // invalidate old login codes
  $pdo->prepare("UPDATE otp_codes SET used_at = NOW()
                 WHERE user_id=? AND purpose='login' AND used_at IS NULL")
      ->execute([$userId]);

  $pdo->prepare("INSERT INTO otp_codes (user_id, code_hash, purpose, expires_at)
                 VALUES (?, ?, 'login', ?)")
      ->execute([$userId, $hash, $expires]);

  $subject = APP_NAME . " 2FA Code";
  $msg = "Your login code is: {$code}\n\nThis code expires in " . (int)(OTP_TTL_SECONDS/60) . " minutes.";

  // Always send from no-reply via SMTP_FROM_EMAIL / MAIL_FROM
  mail_send($email, $subject, $msg);
}

function verify_2fa(int $userId, string $code): void {
  $code = trim($code);
  if (!preg_match('/^\d{6}$/', $code)) throw new Exception("Invalid code format.");

  $pdo = db();
  $st = $pdo->prepare("
    SELECT * FROM otp_codes
    WHERE user_id=? AND purpose='login' AND used_at IS NULL
    ORDER BY id DESC LIMIT 1
  ");
  $st->execute([$userId]);
  $row = $st->fetch();
  if (!$row) throw new Exception("No active code. Try logging in again.");

  $exp = new DateTimeImmutable((string)$row['expires_at']);
  if ($exp < now()) throw new Exception("Code expired. Try logging in again.");

  if (!password_verify($code, (string)$row['code_hash'])) throw new Exception("Incorrect code.");

  $pdo->prepare("UPDATE otp_codes SET used_at = NOW() WHERE id=?")->execute([(int)$row['id']]);
}

/**
 * =========================
 *  OTP (Password reset)
 * =========================
 */

function start_password_reset_email(string $email): void {
  $email = normalize_email_safe($email);

  // Do not reveal existence to the caller
  $pdo = db();
  $st = $pdo->prepare("SELECT id, email FROM users WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $u = $st->fetch();
  if (!$u) {
    return; // silent
  }

  $userId = (int)$u['id'];
  $code = random_otp_code();
  $hash = password_hash($code, PASSWORD_DEFAULT);
  $expires = now()->modify('+' . OTP_TTL_SECONDS . ' seconds')->format('Y-m-d H:i:s');

  // invalidate old reset codes
  $pdo->prepare("UPDATE otp_codes SET used_at = NOW()
                 WHERE user_id=? AND purpose='reset' AND used_at IS NULL")
      ->execute([$userId]);

  $pdo->prepare("INSERT INTO otp_codes (user_id, code_hash, purpose, expires_at)
                 VALUES (?, ?, 'reset', ?)")
      ->execute([$userId, $hash, $expires]);

  $subject = APP_NAME . " Password Reset Code";
  $msg = "Your password reset code is: {$code}\n\n"
       . "This code expires in " . (int)(OTP_TTL_SECONDS/60) . " minutes.\n\n"
       . "If you didn't request this, you can ignore this email.";

  mail_send($email, $subject, $msg);
}

function verify_reset_otp_and_get_user(string $email, string $code): array {
  $email = normalize_email_safe($email);
  $code = trim($code);

  if (!preg_match('/^\d{6}$/', $code)) throw new Exception("Invalid code format.");

  $pdo = db();
  $st = $pdo->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $u = $st->fetch();
  if (!$u) throw new Exception("Invalid code or email.");

  $userId = (int)$u['id'];

  $st2 = $pdo->prepare("
    SELECT * FROM otp_codes
    WHERE user_id=? AND purpose='reset' AND used_at IS NULL
    ORDER BY id DESC LIMIT 1
  ");
  $st2->execute([$userId]);
  $row = $st2->fetch();
  if (!$row) throw new Exception("No active code. Request a new one.");

  $exp = new DateTimeImmutable((string)$row['expires_at']);
  if ($exp < now()) throw new Exception("Code expired. Request a new one.");

  if (!password_verify($code, (string)$row['code_hash'])) throw new Exception("Invalid code or email.");

  // Mark used
  $pdo->prepare("UPDATE otp_codes SET used_at = NOW() WHERE id=?")->execute([(int)$row['id']]);

  return $u;
}

function set_new_password(int $userId, string $newPassword): void {
  if (strlen($newPassword) < 10) throw new Exception("Password must be at least 10 characters.");
  $hash = password_hash($newPassword, PASSWORD_ARGON2ID);
  if (!$hash) throw new Exception("Failed to hash password.");

  db()->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash, $userId]);
}
