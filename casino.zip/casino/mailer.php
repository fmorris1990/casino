<?php
declare(strict_types=1);

require_once __DIR__ . '/security.php'; // for nowIso() if you want, not required

// Hard-coded sender per your request
const MAIL_FROM_ADDR = 'no-reply@fm3holdings.com';
const MAIL_FROM_NAME = 'FM3 Holdings';

function send_email(string $to, string $subject, string $bodyText): bool {
  $to = trim($to);
  if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) return false;

  $from = MAIL_FROM_ADDR;
  $fromName = MAIL_FROM_NAME;

  // Build safer headers
  $headers = [];
  $headers[] = "From: {$fromName} <{$from}>";
  $headers[] = "Reply-To: {$from}";
  $headers[] = "MIME-Version: 1.0";
  $headers[] = "Content-Type: text/plain; charset=UTF-8";
  $headers[] = "Content-Transfer-Encoding: 8bit";
  $headers[] = "X-Mailer: PHP/" . phpversion();

  // IMPORTANT: envelope sender for deliverability + SPF alignment
  $params = "-f {$from}";

  // Use CRLF separator
  $headersStr = implode("\r\n", $headers);

  // Don’t suppress errors during testing; once stable you can re-add @
  return mail($to, $subject, $bodyText, $headersStr, $params);
}
