<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';      // create_user()
require_once __DIR__ . '/security.php';  // csrf helpers + session_boot()

session_boot();
ensure_csrf();

$successEmail = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new Exception("Please enter a valid email address.");
    }
    if (strlen($password) < 10) {
      throw new Exception("Password must be at least 10 characters.");
    }
    if ($password !== $password2) {
      throw new Exception("Passwords do not match.");
    }

    // Create the user (auth.php already normalizes email + hashes password)
    // If your DB has a UNIQUE index on users.email, duplicate will throw
    $uid = create_user($email, $password, null);

    // Show success screen
    $successEmail = normalize_email($email);

    // Optional: you can auto-fill login email for convenience
    $_SESSION['register_success_email'] = $successEmail;

  } catch (Throwable $e) {
    $msg = $e->getMessage();

    // Friendly message for duplicate email (MySQL duplicate key)
    if (stripos($msg, 'Duplicate') !== false || stripos($msg, 'duplicate') !== false) {
      $msg = "That email is already registered. Please log in instead.";
    }

    $error = $msg;
  }
}

$csrf = csrf_token();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Register</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🧾 Create Account</h1>
        <div class="sub">Register with your email. You’ll use email verification codes (2FA) to sign in.</div>
      </div>
      <div class="nav">
        <a class="btn" href="login.php">Login</a>
        <a class="btn active" href="register.php">Register</a>
      </div>
    </div>

    <?php if ($successEmail): ?>
      <div class="box" style="margin-top:14px;">
        <div class="msg">
          <div class="ok">
            ✅ Registration successful!<br/>
            <span class="small">Account created for: <b><?php echo htmlspecialchars($successEmail); ?></b></span>
          </div>
        </div>

        <div class="callout" style="margin-top:12px;">
          <b>Next step:</b><br/>
          Go to the login page and sign in. You’ll receive a verification code by email.
        </div>

        <div class="actions" style="margin-top:12px;">
          <a class="btn" href="login.php">➡️ Go to Login</a>
          <a class="btn secondary" href="register.php">Register another</a>
        </div>
      </div>

    <?php else: ?>
      <?php if ($error): ?>
        <div class="msg" style="margin-top:12px;">
          <div class="err"><?php echo htmlspecialchars($error); ?></div>
        </div>
      <?php endif; ?>

      <form method="post" class="box" style="margin-top:14px;">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($csrf); ?>"/>

        <div class="small"><b>Email</b></div>
        <input
          name="email"
          type="email"
          autocomplete="email"
          required
          placeholder="you@example.com"
          value="<?php echo htmlspecialchars((string)($_POST['email'] ?? '')); ?>"
          style="margin-top:6px; width:100%;"
        />

        <div class="small" style="margin-top:12px;"><b>Password</b></div>
        <input
          name="password"
          type="password"
          autocomplete="new-password"
          required
          placeholder="At least 10 characters"
          style="margin-top:6px; width:100%;"
        />

        <div class="small" style="margin-top:12px;"><b>Confirm Password</b></div>
        <input
          name="password2"
          type="password"
          autocomplete="new-password"
          required
          placeholder="Re-enter password"
          style="margin-top:6px; width:100%;"
        />

        <div class="actions" style="margin-top:14px;">
          <button class="btn" type="submit">✅ Create Account</button>
          <a class="btn secondary" href="login.php">Already registered? Login</a>
        </div>

        <div class="small" style="opacity:.85; margin-top:12px; line-height:1.5;">
          By registering, you agree to keep your login and verification codes private.
          This platform is for entertainment only with virtual credits.
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
