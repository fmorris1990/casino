<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';

$admin = require_admin();
$csrf  = csrf_token();

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Admin • Users</title>
  <link rel="stylesheet" href="style.css"/>
  <style>
    .adminGrid{ display:grid; gap:14px; grid-template-columns: 1.4fr .9fr; }
    @media (max-width: 980px){ .adminGrid{ grid-template-columns: 1fr; } }
    .table{ width:100%; border-collapse: collapse; }
    .table th,.table td{ padding:10px 10px; border-bottom:1px solid rgba(255,255,255,.10); vertical-align: top; }
    .table th{ text-align:left; font-size:12px; opacity:.85; letter-spacing:.2px; }
    tr.urow{ cursor:pointer; }
    tr.urow:hover{ background: rgba(255,255,255,.04); }
    tr.urow.sel{ outline: 1px solid rgba(120,220,255,.35); background: rgba(120,220,255,.06); }
    .chip{ display:inline-flex; align-items:center; gap:6px; padding:2px 8px; border-radius:999px; border:1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); font-size:12px; margin-right:6px; margin-top:6px; }
    .chip.red{ border-color: rgba(255,120,120,.35); background: rgba(255,80,80,.08); }
    .chip.green{ border-color: rgba(140,255,170,.25); background: rgba(140,255,170,.08); }
    .mono{ font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
    .small2{ font-size:12px; opacity:.85; }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🛡️ Admin • Users</h1>
        <div class="sub">Manage players: credits, bans, and session stats. (Admin only)</div>
      </div>
      <div class="nav">
        <a class="btn" href="casino.php">🏠 Hub</a>
        <a class="btn" href="admin_security.php">🧪 Security</a>
        <a class="btn active" href="admin_users.php">👥 Users</a>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="pillrow" style="margin-top:12px;">
      <div class="pill">Signed in: <strong><?php echo htmlspecialchars((string)$admin['email']); ?></strong></div>
      <div class="pill">Role: <strong>Admin</strong></div>
      <div class="pill">CSRF: <span class="mono"><?php echo htmlspecialchars(substr($csrf,0,8)); ?>…</span></div>
    </div>
  </div>

  <div class="adminGrid" style="margin-top:14px;">
    <div class="card">
      <div class="actions" style="gap:10px;">
        <input id="q" placeholder="Search email…" style="min-width:220px;" />
        <button onclick="reload()">Search</button>
        <button class="secondary" onclick="reload(true)">Refresh</button>
      </div>

      <div id="msg" class="msg"></div>

      <div class="box" style="margin-top:12px; overflow:auto;">
        <table class="table">
          <thead>
            <tr>
              <th style="min-width:260px;">User</th>
              <th style="min-width:160px;">Credits</th>
              <th style="min-width:180px;">Status</th>
              <th style="min-width:220px;">Totals</th>
            </tr>
          </thead>
          <tbody id="rows">
            <tr><td colspan="4" class="small">Loading…</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <h2 style="margin:0; font-size:18px;">🎯 Selected User</h2>
      <div class="sub">Click a row or the Select button to load a user.</div>

      <div class="box" style="margin-top:12px;">
        <div class="small2">Email</div>
        <div><b id="sel-email">—</b></div>
        <div class="small2" style="margin-top:10px;">User ID</div>
        <div class="mono" id="sel-id">—</div>
        <div class="small2" style="margin-top:10px;">Credits</div>
        <div><b id="sel-credits">—</b></div>
        <div class="small2" style="margin-top:10px;">Session High</div>
        <div><b id="sel-high">—</b></div>
        <div class="small2" style="margin-top:10px;">Flags</div>
        <div id="sel-flags" style="margin-top:6px;">—</div>
      </div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>Adjust Credits</b></div>
        <div class="small2" style="margin-top:6px;">Use + to add, - to remove.</div>
        <div class="actions" style="margin-top:10px;">
          <input type="number" id="delta" step="1" value="1000" />
          <button onclick="applyCredits()">Apply</button>
        </div>
      </div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>Account Controls</b></div>
        <div class="actions" style="margin-top:10px;">
          <button class="secondary danger" onclick="banToggle(true)">Ban</button>
          <button class="secondary" onclick="banToggle(false)">Unban</button>
        </div>
      </div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>Notes</b></div>
        <div class="small2" style="margin-top:6px;">
          - Banned users cannot enter the casino.<br/>
          - Credits are DB-backed; game hands/history remain session-based.
        </div>
      </div>
    </div>
  </div>
</div>

<script>
const CSRF = <?php echo json_encode($csrf); ?>;

let SELECTED_ID = 0;
let SELECTED_EMAIL = '';

async function api(op, payload={}){
  const res = await fetch('admin_users_api.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ op, csrf: CSRF, ...payload })
  });
  const data = await res.json().catch(()=> ({}));
  if(!res.ok || !data.ok) throw new Error(data?.error || 'Request failed');
  return data;
}

function money(n){ return String(Math.floor(Number(n||0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function setMsg(type, text){
  const el = document.getElementById('msg');
  el.innerHTML = text ? `<div class="${type==='err'?'err':'ok'}">${text}</div>` : '';
}
function chip(text, cls=''){
  return `<span class="chip ${cls}">${text}</span>`;
}
function rowTags(u){
  let out='';
  if(Number(u.is_admin) === 1) out += chip('Admin','green');
  if(Number(u.is_banned) === 1) out += chip('Banned','red');
  if(Number(u.twofa_enabled) === 1) out += chip('2FA','');
  return out || '—';
}

function renderRows(users){
  const tbody = document.getElementById('rows');
  if(!users.length){
    tbody.innerHTML = `<tr><td colspan="4" class="small">No users found.</td></tr>`;
    return;
  }

  tbody.innerHTML = users.map(u=>{
    const email = String(u.email || '');
    const selected = (Number(u.id) === Number(SELECTED_ID)) ? 'sel' : '';
    return `
      <tr class="urow ${selected}" data-uid="${Number(u.id)}" data-email="${email.replace(/"/g,'&quot;')}">
        <td>
          <div class="row" style="align-items:flex-start; justify-content:space-between; gap:10px;">
            <div>
              <div><b>${email}</b></div>
              <div class="small">Created ${u.created_at || '—'}</div>
            </div>
            <div>
              <button type="button" class="btn" style="height:32px; padding:0 10px;">Select</button>
            </div>
          </div>
        </td>
        <td>
          <div><b>${money(u.credits)}</b></div>
          <div class="small">Start ${money(u.start_credits || 0)} • High ${money(u.session_high_credits || 0)}</div>
        </td>
        <td>${rowTags(u)}</td>
        <td>
          <div class="small">Wagered ${money(u.total_wagered || 0)}</div>
          <div class="small">Won ${money(u.total_won || 0)}</div>
        </td>
      </tr>
    `;
  }).join('');
}

function selectUser(id, email){
  SELECTED_ID = Number(id);
  SELECTED_EMAIL = String(email || '');
  renderSelected();
  // update row highlight
  document.querySelectorAll('tr.urow').forEach(tr=>{
    tr.classList.toggle('sel', Number(tr.dataset.uid) === SELECTED_ID);
  });
  setMsg('', '');
}

function renderSelected(){
  document.getElementById('sel-id').textContent = SELECTED_ID ? String(SELECTED_ID) : '—';
  document.getElementById('sel-email').textContent = SELECTED_EMAIL || '—';
}

function renderSelectedDetails(u){
  document.getElementById('sel-credits').textContent = money(u.credits);
  document.getElementById('sel-high').textContent = money(u.session_high_credits || 0);
  let flags = '';
  if(Number(u.is_admin) === 1) flags += chip('Admin','green');
  if(Number(u.is_banned) === 1) flags += chip('Banned','red');
  if(Number(u.twofa_enabled) === 1) flags += chip('2FA','');
  document.getElementById('sel-flags').innerHTML = flags || '—';
}

async function reload(clear=false){
  setMsg('', '');
  if(clear){
    document.getElementById('q').value = '';
  }
  const q = String(document.getElementById('q').value || '').trim();
  try{
    const d = await api('users_list', { q });
    renderRows(d.users || []);
    // If a user is already selected, refresh their detail panel
    if(SELECTED_ID){
      const found = (d.users || []).find(x => Number(x.id) === Number(SELECTED_ID));
      if(found) {
        SELECTED_EMAIL = String(found.email || SELECTED_EMAIL);
        renderSelected();
        renderSelectedDetails(found);
      }
    }
  } catch(e){
    setMsg('err', e.message);
  }
}

// Event delegation for reliable selection
document.addEventListener('click', (e)=>{
  const tr = e.target.closest('tr.urow');
  if(!tr) return;
  const uid = Number(tr.dataset.uid || 0);
  const email = String(tr.dataset.email || '');
  if(uid > 0) selectUser(uid, email);
});

async function applyCredits(){
  if(!SELECTED_ID) return setMsg('err','Select a user first.');
  const delta = Math.trunc(Number(document.getElementById('delta').value || 0));
  if(!delta) return setMsg('err','Enter a non-zero amount.');
  if(!confirm(`Apply ${delta>0?'+':''}${delta} credits to ${SELECTED_EMAIL}?`)) return;
  setMsg('', '');
  try{
    const d = await api('credits_adjust', { userId: SELECTED_ID, delta });
    setMsg('ok', d.message || 'Credits updated.');
    renderSelectedDetails(d.user);
    reload(); // refresh list
  } catch(e){
    setMsg('err', e.message);
  }
}

async function banToggle(on){
  if(!SELECTED_ID) return setMsg('err','Select a user first.');
  const verb = on ? 'BAN' : 'UNBAN';
  if(!confirm(`${verb} ${SELECTED_EMAIL}?`)) return;
  setMsg('', '');
  try{
    const d = await api('ban_set', { userId: SELECTED_ID, banned: !!on });
    setMsg('ok', d.message || 'Updated.');
    renderSelectedDetails(d.user);
    reload();
  } catch(e){
    setMsg('err', e.message);
  }
}

// initial selected state
renderSelected();
reload();
</script>
</body>
</html>
