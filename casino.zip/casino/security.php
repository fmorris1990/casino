<?php
declare(strict_types=1);

if (!function_exists('now')) {
  function now(): DateTimeImmutable { return new DateTimeImmutable('now'); }
}
if (!function_exists('nowIso')) {
  function nowIso(): string { return now()->format('Y-m-d H:i:s'); }
}

if (!function_exists('session_boot')) {
  function session_boot(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

    // Cookie must work for /casino/*
    session_set_cookie_params([
      'lifetime' => 0,
      'path' => '/casino',
      'domain' => '',
      'secure' => $secure,
      'httponly' => true,
      'samesite' => 'Lax',
    ]);

    session_start();
  }
}

if (!function_exists('ensure_csrf')) {
  function ensure_csrf(): void {
    session_boot();
    if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
  }
}
if (!function_exists('csrf_token')) {
  function csrf_token(): string {
    ensure_csrf();
    return (string)$_SESSION['csrf'];
  }
}
if (!function_exists('csrf_check')) {
  function csrf_check(?string $token): void {
    ensure_csrf();
    $t = (string)$token;
    if ($t === '' || !hash_equals((string)$_SESSION['csrf'], $t)) {
      throw new Exception('Invalid CSRF. Refresh and try again.');
    }
  }
}

if (!function_exists('normalize_email')) {
  function normalize_email(string $email): string {
    return strtolower(trim($email));
  }
}
if (!function_exists('random_otp_code')) {
  function random_otp_code(): string {
    return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
  }
}
if (!function_exists('clamp_int')) {
  function clamp_int($value, int $min, int $max): ?int {
    $n = filter_var($value, FILTER_VALIDATE_INT);
    if ($n === false) return null;
    if ($n < $min || $n > $max) return null;
    return $n;
  }
}

/* ========= Hardening helpers ========= */

if (!function_exists('client_ip')) {
  function client_ip(): string {
    // Prefer server-provided REMOTE_ADDR; do NOT trust X-Forwarded-For unless you control proxy.
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    if ($ip === '') $ip = '0.0.0.0';
    return $ip;
  }
}

if (!function_exists('rate_limit_key')) {
  function rate_limit_key(string $name, string $scope): string {
    $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $scope);
    return $name . '__' . $safe;
  }
}

if (!function_exists('rate_limit_hit')) {
  /**
   * Simple file-based rate limit (no DB required).
   * @return bool true if allowed, false if limited
   */
  function rate_limit_hit(string $name, string $scope, int $maxHits, int $windowSeconds): bool {
    $dir = __DIR__ . '/_ratelimit';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);

    $key = rate_limit_key($name, $scope);
    $file = $dir . '/' . hash('sha256', $key) . '.json';

    $now = time();
    $data = ['t'=>$now,'n'=>0];
    if (is_file($file)) {
      $raw = (string)@file_get_contents($file);
      $j = json_decode($raw, true);
      if (is_array($j) && isset($j['t'],$j['n'])) $data = $j;
    }

    // Reset window if expired
    if (($now - (int)$data['t']) > $windowSeconds) {
      $data = ['t'=>$now,'n'=>0];
    }

    $data['n'] = (int)$data['n'] + 1;

    @file_put_contents($file, json_encode($data), LOCK_EX);

    return ((int)$data['n'] <= $maxHits);
  }
}
