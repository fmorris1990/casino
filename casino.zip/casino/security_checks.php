<?php
declare(strict_types=1);

function header_val(string $name): ?string {
  foreach (headers_list() as $h) {
    if (stripos($h, $name . ':') === 0) return trim(substr($h, strlen($name) + 1));
  }
  return null;
}

function https_active(): bool {
  if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
  if (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) return true;
  if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
  return false;
}

function php_env_checks(): array {
  $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
  $disabled = array_filter($disabled, fn($x)=>$x!=='');
  $execDisabled = in_array('exec', $disabled, true) || in_array('shell_exec', $disabled, true);

  return [
    'php_version' => PHP_VERSION,
    'https_active' => https_active(),
    'session_save_path' => (string)ini_get('session.save_path'),
    'session_cookie_secure' => (bool)ini_get('session.cookie_secure'),
    'session_cookie_httponly' => (bool)ini_get('session.cookie_httponly'),
    'expose_php' => (bool)ini_get('expose_php'),
    'display_errors' => (bool)ini_get('display_errors'),
    'exec_available' => !$execDisabled,
    'disabled_functions' => $disabled,
  ];
}

function security_header_checks(): array {
  // These are response headers your app should ideally send on HTTPS pages
  $want = [
    'Strict-Transport-Security',
    'Content-Security-Policy',
    'X-Content-Type-Options',
    'X-Frame-Options',
    'Referrer-Policy',
    'Permissions-Policy',
  ];
  $present = [];
  foreach ($want as $h) $present[$h] = header_val($h);

  return $present;
}

/**
 * Best-effort local port snapshot (only if exec allowed).
 * This is not a "scan"—it just lists local listening sockets if permitted.
 */
function local_listening_ports(): array {
  $out = [
    'supported' => false,
    'method' => null,
    'raw' => null,
    'ports' => [],
    'note' => null,
  ];

  $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
  $disabled = array_filter($disabled, fn($x)=>$x!=='');
  if (in_array('shell_exec', $disabled, true)) {
    $out['note'] = 'shell_exec is disabled on this host (common on shared hosting).';
    return $out;
  }

  // Try ss first, then netstat
  $cmds = [
    ['method'=>'ss', 'cmd'=>'ss -lntp 2>/dev/null || ss -lntu 2>/dev/null'],
    ['method'=>'netstat', 'cmd'=>'netstat -lntp 2>/dev/null || netstat -lntu 2>/dev/null'],
  ];

  foreach ($cmds as $c) {
    $raw = @shell_exec($c['cmd']);
    if (is_string($raw) && trim($raw) !== '') {
      $out['supported'] = true;
      $out['method'] = $c['method'];
      $out['raw'] = $raw;

      // Extract port numbers
      preg_match_all('/:(\d+)\s/', $raw, $m);
      $ports = [];
      foreach (($m[1] ?? []) as $p) $ports[(int)$p] = true;
      $out['ports'] = array_values(array_map('intval', array_keys($ports)));
      sort($out['ports']);
      return $out;
    }
  }

  $out['note'] = 'No socket tool available or command blocked by host policy.';
  return $out;
}

function app_path_safety(): array {
  // Checks for risky files in /casino (basic)
  $base = __DIR__;
  $flags = [];

  $risky = ['.env', 'composer.lock', 'composer.json', 'phpinfo.php', 'debug.php', 'debug2.php'];
  foreach ($risky as $f) {
    $p = $base . '/' . $f;
    if (file_exists($p)) $flags[] = "Found file: {$f} (remove or protect in production).";
  }

  // Ensure sensitive dirs not world-readable is hard on shared hosting; just warn.
  return [
    'base' => $base,
    'warnings' => $flags,
  ];
}
