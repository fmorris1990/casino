<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';

session_boot();
ensure_csrf();

$done = false;
$msg = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $email = trim((string)($_POST['email'] ?? ''));
    $code  = trim((string)($_POST['code'] ?? ''));
    $p1    = (string)($_POST['password'] ?? '');
    $p2    = (string)($_POST['password2'] ?? '');

    if ($p1 === '' || $p2 === '') throw new Exception("Please enter the new password twice.");
    if ($p1 !== $p2) throw new Exception("Passwords do not match.");

    $u = verify_reset_otp_and_get_user($email, $code);
    set_new_password((int)$u['id'], $p1);

    $done = true;
    $msg = "✅ Password updated successfully for {$u['email']}. Please log in with your new password.";
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$csrf = csrf_token();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Reset Password</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🔐 Reset Password</h1>
        <div class="sub">Enter the code we emailed you and choose a new password.</div>
      </div>
      <div class="nav">
        <a class="btn" href="login.php">Login</a>
        <a class="btn" href="forgot.php">Request Code</a>
        <a class="btn active" href="reset.php">Reset</a>
      </div>
    </div>

    <?php if ($msg): ?>
      <div class="msg" style="margin-top:12px;"><div class="ok"><?php echo htmlspecialchars($msg); ?></div></div>
    <?php endif; ?>
    <?php if ($err): ?>
      <div class="msg" style="margin-top:12px;"><div class="err"><?php echo htmlspecialchars($err); ?></div></div>
    <?php endif; ?>

    <?php if ($done): ?>
      <div class="actions" style="margin-top:12px;">
        <a class="btn" href="login.php">➡️ Go to Login</a>
      </div>
    <?php else: ?>
      <form method="post" class="box" style="margin-top:14px;">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($csrf); ?>"/>

        <div class="small"><b>Email</b></div>
        <input
          type="email"
          name="email"
          required
          autocomplete="email"
          placeholder="you@example.com"
          style="margin-top:6px;"
        />

        <div class="small" style="margin-top:12px;"><b>Reset Code</b></div>
        <input
          type="text"
          name="code"
          required
          inputmode="numeric"
          pattern="\d{6}"
          maxlength="6"
          placeholder="6-digit code"
          style="margin-top:6px;"
        />

        <div class="small" style="margin-top:12px;"><b>New Password</b></div>
        <input
          type="password"
          name="password"
          required
          minlength="10"
          autocomplete="new-password"
          placeholder="At least 10 characters"
          style="margin-top:6px;"
        />

        <div class="small" style="margin-top:12px;"><b>Confirm New Password</b></div>
        <input
          type="password"
          name="password2"
          required
          minlength="10"
          autocomplete="new-password"
          placeholder="Re-type password"
          style="margin-top:6px;"
        />

        <div class="actions" style="margin-top:14px;">
          <button class="btn" type="submit">✅ Update Password</button>
          <a class="btn secondary" href="forgot.php">Resend Code</a>
        </div>

        <div class="small" style="opacity:.85; margin-top:10px;">
          Security note: never share your reset code with anyone.
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
