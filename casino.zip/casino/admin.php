<?php
declare(strict_types=1);

require __DIR__ . '/common.php'; // requires login + session + csrf in your stack
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';

session_boot();
ensure_csrf();

$admin = require_admin();
$pdo = db();

$tab = (string)($_GET['tab'] ?? 'users');
$tab = in_array($tab, ['users','security','audit'], true) ? $tab : 'users';

$q = trim((string)($_GET['q'] ?? ''));
$uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;

$flashOk = null;
$flashErr = null;

/* -------- Audit logger (graceful if table missing) -------- */
function admin_audit_log(
  PDO $pdo,
  int $adminId,
  string $action,
  ?int $targetUserId = null,
  array $details = []
): void {
  $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
  $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
  $detailsJson = json_encode($details, JSON_UNESCAPED_SLASHES);

  try {
    // Expected table: admin_audit_log
    // columns: id, admin_id, action, target_user_id, details_json, ip, user_agent, created_at
    $st = $pdo->prepare("
      INSERT INTO admin_audit_log (admin_id, action, target_user_id, details_json, ip, user_agent, created_at)
      VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $st->execute([$adminId, $action, $targetUserId, $detailsJson, $ip, $ua]);
  } catch (Throwable $e) {
    // Do not fatal if table doesn't exist yet
  }
}

/* -------- Helpers -------- */
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function get_user_by_id(PDO $pdo, int $uid): ?array {
  if ($uid <= 0) return null;
  $st = $pdo->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
  $st->execute([$uid]);
  $row = $st->fetch();
  return $row ?: null;
}

function user_sessions_count(PDO $pdo, int $uid): int {
  try {
    $st = $pdo->prepare("SELECT COUNT(*) AS c FROM user_sessions WHERE user_id=?");
    $st->execute([$uid]);
    $r = $st->fetch();
    return (int)($r['c'] ?? 0);
  } catch (Throwable $e) {
    return 0;
  }
}

function revoke_user_sessions(PDO $pdo, int $uid): int {
  try {
    $st = $pdo->prepare("DELETE FROM user_sessions WHERE user_id=?");
    $st->execute([$uid]);
    return $st->rowCount();
  } catch (Throwable $e) {
    return 0;
  }
}

/* -------- POST Actions -------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $action = (string)($_POST['action'] ?? '');
    $target = (int)($_POST['uid'] ?? 0);

    if ($target <= 0) throw new Exception("No user selected.");

    $targetRow = get_user_by_id($pdo, $target);
    if (!$targetRow) throw new Exception("User not found.");

    // Credits
    if ($action === 'credits_add') {
      $amt = (int)($_POST['amount'] ?? 0);
      if ($amt <= 0) throw new Exception("Amount must be > 0.");
      $st = $pdo->prepare("UPDATE users SET credits = credits + ? WHERE id=?");
      $st->execute([$amt, $target]);

      admin_audit_log($pdo, (int)$admin['id'], 'credits_add', $target, ['amount'=>$amt]);
      $flashOk = "Added {$amt} credits to ".(string)$targetRow['email'].".";

    } elseif ($action === 'credits_remove') {
      $amt = (int)($_POST['amount'] ?? 0);
      if ($amt <= 0) throw new Exception("Amount must be > 0.");
      // Prevent negatives
      $st = $pdo->prepare("UPDATE users SET credits = GREATEST(0, credits - ?) WHERE id=?");
      $st->execute([$amt, $target]);

      admin_audit_log($pdo, (int)$admin['id'], 'credits_remove', $target, ['amount'=>$amt]);
      $flashOk = "Removed {$amt} credits from ".(string)$targetRow['email'].".";

    } elseif ($action === 'credits_set') {
      $amt = (int)($_POST['amount'] ?? -1);
      if ($amt < 0) throw new Exception("Amount must be >= 0.");
      $st = $pdo->prepare("UPDATE users SET credits = ? WHERE id=?");
      $st->execute([$amt, $target]);

      admin_audit_log($pdo, (int)$admin['id'], 'credits_set', $target, ['amount'=>$amt]);
      $flashOk = "Set credits to {$amt} for ".(string)$targetRow['email'].".";

    // Ban/unban
    } elseif ($action === 'ban') {
      $st = $pdo->prepare("UPDATE users SET is_banned=1 WHERE id=?");
      $st->execute([$target]);

      // Also revoke sessions for immediate effect
      $revoked = revoke_user_sessions($pdo, $target);

      admin_audit_log($pdo, (int)$admin['id'], 'ban', $target, ['revoked_sessions'=>$revoked]);
      $flashOk = "Banned ".(string)$targetRow['email']." (revoked {$revoked} sessions).";

    } elseif ($action === 'unban') {
      $st = $pdo->prepare("UPDATE users SET is_banned=0 WHERE id=?");
      $st->execute([$target]);

      admin_audit_log($pdo, (int)$admin['id'], 'unban', $target, []);
      $flashOk = "Unbanned ".(string)$targetRow['email'].".";

    // Session baseline / highs
    } elseif ($action === 'reset_start') {
      $st = $pdo->prepare("UPDATE users SET start_credits = credits WHERE id=?");
      $st->execute([$target]);

      admin_audit_log($pdo, (int)$admin['id'], 'reset_start_credits', $target, []);
      $flashOk = "Reset start_credits to current credits for ".(string)$targetRow['email'].".";

    } elseif ($action === 'reset_high') {
      $st = $pdo->prepare("UPDATE users SET session_high_credits = credits WHERE id=?");
      $st->execute([$target]);

      admin_audit_log($pdo, (int)$admin['id'], 'reset_session_high', $target, []);
      $flashOk = "Reset session high to current credits for ".(string)$targetRow['email'].".";

    // Security: revoke sessions
    } elseif ($action === 'revoke_sessions') {
      $revoked = revoke_user_sessions($pdo, $target);

      admin_audit_log($pdo, (int)$admin['id'], 'revoke_sessions', $target, ['revoked'=>$revoked]);
      $flashOk = "Revoked {$revoked} sessions for ".(string)$targetRow['email'].".";

    } else {
      throw new Exception("Unknown action.");
    }

    // Redirect to avoid resubmission
    $redirTab = in_array($tab, ['users','security','audit'], true) ? $tab : 'users';
    $redir = "admin.php?tab=".urlencode($redirTab)."&uid=".$target;
    if ($q !== '') $redir .= "&q=".urlencode($q);
    header("Location: ".$redir);
    exit;

  } catch (Throwable $e) {
    $flashErr = $e->getMessage();
  }
}

/* -------- Load data for UI -------- */
$selected = $uid > 0 ? get_user_by_id($pdo, $uid) : null;

// user list (search)
$userRows = [];
try {
  if ($q !== '') {
    $st = $pdo->prepare("
      SELECT id, email, is_admin, is_banned, credits, start_credits, session_high_credits, updated_at, created_at
      FROM users
      WHERE email LIKE ?
      ORDER BY id DESC
      LIMIT 200
    ");
    $st->execute(['%'.$q.'%']);
  } else {
    $st = $pdo->query("
      SELECT id, email, is_admin, is_banned, credits, start_credits, session_high_credits, updated_at, created_at
      FROM users
      ORDER BY id DESC
      LIMIT 200
    ");
  }
  $userRows = $st->fetchAll() ?: [];
} catch (Throwable $e) {
  $userRows = [];
}

// Security data: recent OTP attempts (if exists)
$otpRows = [];
try {
  $otpRows = $pdo->query("
    SELECT id, user_id, purpose, expires_at, used_at, created_at
    FROM otp_codes
    ORDER BY id DESC
    LIMIT 30
  ")->fetchAll() ?: [];
} catch (Throwable $e) {
  $otpRows = [];
}

// Audit rows (if exists)
$auditRows = [];
try {
  $auditRows = $pdo->query("
    SELECT id, admin_id, action, target_user_id, details_json, ip, user_agent, created_at
    FROM admin_audit_log
    ORDER BY id DESC
    LIMIT 80
  ")->fetchAll() ?: [];
} catch (Throwable $e) {
  $auditRows = [];
}

$csrf = csrf_token();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Admin Panel</title>
  <link rel="stylesheet" href="style.css"/>
  <style>
    .adminGrid{ display:grid; grid-template-columns: 1fr 1.2fr; gap:14px; }
    @media (max-width: 980px){ .adminGrid{ grid-template-columns:1fr; } }
    .rowBtn{ width:100%; text-align:left; padding:10px 12px; border-radius:14px; border:1px solid rgba(255,255,255,.10);
      background: rgba(0,0,0,.10); color:inherit; cursor:pointer; }
    .rowBtn:hover{ border-color: rgba(255,255,255,.18); }
    .rowBtn.active{ border-color: rgba(120,220,255,.35); background: rgba(120,220,255,.08); }
    .mini{ font-size:12px; opacity:.86; }
    .twoCol{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
    @media (max-width: 720px){ .twoCol{ grid-template-columns:1fr; } }
    .dangerZone{ border:1px solid rgba(255,120,120,.22); background: rgba(255,0,0,.05); border-radius:16px; padding:12px; }
    .tabs{ display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
    .tabs .btn{ height:34px; padding:0 12px; display:inline-flex; align-items:center; }
    .table{ width:100%; border-collapse:separate; border-spacing:0; overflow:hidden; border-radius:14px; border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.10); }
    .table th,.table td{ padding:10px 12px; border-bottom:1px solid rgba(255,255,255,.08); font-size:13px; vertical-align:top; }
    .table th{ text-align:left; font-weight:900; background: rgba(255,255,255,.05); }
    .table tr:last-child td{ border-bottom:none; }
    .pillSm{ display:inline-flex; padding:2px 8px; border-radius:999px; border:1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); font-size:12px; opacity:.95; }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🛠️ Admin Panel</h1>
        <div class="sub">Manage users, security, and audit logs.</div>
        <div class="mini" style="margin-top:6px;">Signed in as: <b><?php echo h((string)$admin['email']); ?></b></div>
      </div>
      <div class="nav">
        <a class="btn" href="casino.php">🏠 Hub</a>
        <a class="btn active" href="admin.php">🛠️ Admin</a>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="tabs">
      <a class="btn <?php echo $tab==='users'?'active':''; ?>" href="admin.php?tab=users<?php echo $q!==''?'&q='.urlencode($q):''; ?><?php echo $uid>0?'&uid='.$uid:''; ?>">👥 Users</a>
      <a class="btn <?php echo $tab==='security'?'active':''; ?>" href="admin.php?tab=security<?php echo $q!==''?'&q='.urlencode($q):''; ?><?php echo $uid>0?'&uid='.$uid:''; ?>">🛡️ Security</a>
      <a class="btn <?php echo $tab==='audit'?'active':''; ?>" href="admin.php?tab=audit">🧾 Audit</a>
    </div>

    <?php if ($flashErr): ?>
      <div class="msg" style="margin-top:12px;"><div class="err"><?php echo h($flashErr); ?></div></div>
    <?php endif; ?>
  </div>

  <div class="adminGrid" style="margin-top:14px;">
    <!-- LEFT: User list -->
    <div class="card">
      <div style="display:flex; gap:10px; align-items:center; justify-content:space-between;">
        <div>
          <h2 style="margin:0; font-size:18px;">Users</h2>
          <div class="mini">Click an email to select the user.</div>
        </div>
      </div>

      <form method="get" style="margin-top:12px; display:flex; gap:10px;">
        <input type="hidden" name="tab" value="<?php echo h($tab); ?>"/>
        <input type="text" name="q" placeholder="Search email..." value="<?php echo h($q); ?>" style="width:100%;"/>
        <button class="btn" type="submit">Search</button>
        <?php if ($q !== ''): ?>
          <a class="btn secondary" href="admin.php?tab=<?php echo h($tab); ?>">Clear</a>
        <?php endif; ?>
      </form>

      <div style="display:grid; gap:10px; margin-top:12px;">
        <?php if (!$userRows): ?>
          <div class="histitem">No users found.</div>
        <?php else: ?>
          <?php foreach ($userRows as $u): ?>
            <?php
              $isActive = ($uid > 0 && (int)$u['id'] === $uid);
              $badges = [];
              if ((int)$u['is_admin'] === 1) $badges[] = 'ADMIN';
              if ((int)$u['is_banned'] === 1) $badges[] = 'BANNED';
            ?>
            <a class="rowBtn <?php echo $isActive?'active':''; ?>"
               href="admin.php?tab=<?php echo h($tab); ?>&uid=<?php echo (int)$u['id']; ?><?php echo $q!==''?'&q='.urlencode($q):''; ?>">
              <div style="display:flex; justify-content:space-between; gap:10px;">
                <div>
                  <div style="font-weight:900;"><?php echo h((string)$u['email']); ?></div>
                  <div class="mini">id #<?php echo (int)$u['id']; ?> • credits <?php echo (int)$u['credits']; ?></div>
                </div>
                <div style="display:flex; gap:6px; align-items:flex-start; flex-wrap:wrap; justify-content:flex-end;">
                  <?php foreach ($badges as $b): ?>
                    <span class="pillSm"><?php echo h($b); ?></span>
                  <?php endforeach; ?>
                </div>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- RIGHT: Selected user + actions / tabs -->
    <div class="card">
      <h2 style="margin:0; font-size:18px;">
        <?php echo $selected ? "Selected: ".h((string)$selected['email']) : "Select a user"; ?>
      </h2>
      <div class="mini" style="margin-top:6px;">
        <?php if ($selected): ?>
          id #<?php echo (int)$selected['id']; ?> • credits <?php echo (int)$selected['credits']; ?> •
          start <?php echo (int)$selected['start_credits']; ?> • high <?php echo (int)$selected['session_high_credits']; ?> •
          sessions <?php echo (int)user_sessions_count($pdo, (int)$selected['id']); ?>
        <?php else: ?>
          Click an email from the list to manage that user.
        <?php endif; ?>
      </div>

      <?php if ($tab === 'users'): ?>
        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Credits</b></div>

          <form method="post" class="twoCol" style="margin-top:10px;">
            <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
            <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>

            <div>
              <div class="mini">Amount</div>
              <input type="number" name="amount" min="0" step="1" value="1000" style="width:100%;"/>
            </div>

            <div style="display:flex; gap:8px; align-items:flex-end; flex-wrap:wrap;">
              <button class="btn" name="action" value="credits_add" type="submit">➕ Add</button>
              <button class="btn secondary" name="action" value="credits_remove" type="submit">➖ Remove</button>
              <button class="btn secondary" name="action" value="credits_set" type="submit">🎯 Set</button>
            </div>
          </form>

          <div class="small" style="opacity:.85; margin-top:10px;">
            “Set” overwrites the user’s credits. Remove will not drop below 0.
          </div>
        </div>

        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Status</b></div>

          <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
            <form method="post">
              <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
              <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>
              <button class="btn danger" name="action" value="ban" type="submit"
                onclick="return confirm('Ban this user and revoke their sessions?');">🚫 Ban</button>
            </form>

            <form method="post">
              <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
              <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>
              <button class="btn secondary" name="action" value="unban" type="submit">✅ Unban</button>
            </form>

            <form method="post">
              <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
              <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>
              <button class="btn secondary" name="action" value="reset_start" type="submit"
                onclick="return confirm('Reset start_credits to current credits?');">🔁 Reset Start</button>
            </form>

            <form method="post">
              <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
              <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>
              <button class="btn secondary" name="action" value="reset_high" type="submit"
                onclick="return confirm('Reset session_high_credits to current credits?');">🏁 Reset High</button>
            </form>
          </div>
        </div>

      <?php elseif ($tab === 'security'): ?>
        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Active Sessions</b></div>
          <div class="mini" style="margin-top:8px;">
            Revoke sessions to force a user to log in again.
          </div>

          <div style="display:flex; gap:10px; align-items:center; justify-content:space-between; margin-top:10px; flex-wrap:wrap;">
            <div>
              <div class="mini">Selected user sessions:</div>
              <div style="font-weight:900; font-size:16px;">
                <?php echo $selected ? (int)user_sessions_count($pdo, (int)$selected['id']) : 0; ?>
              </div>
            </div>

            <form method="post">
              <input type="hidden" name="csrf" value="<?php echo h($csrf); ?>"/>
              <input type="hidden" name="uid" value="<?php echo (int)$uid; ?>"/>
              <button class="btn danger" name="action" value="revoke_sessions" type="submit"
                onclick="return confirm('Revoke all sessions for this user?');">🧹 Revoke Sessions</button>
            </form>
          </div>
        </div>

        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Recent OTP Activity</b></div>
          <?php if (!$otpRows): ?>
            <div class="histitem" style="margin-top:10px;">No OTP records (or otp_codes table not found).</div>
          <?php else: ?>
            <table class="table" style="margin-top:10px;">
              <tr>
                <th>ID</th><th>User</th><th>Purpose</th><th>Expires</th><th>Used</th><th>Created</th>
              </tr>
              <?php foreach ($otpRows as $r): ?>
                <tr>
                  <td><?php echo (int)$r['id']; ?></td>
                  <td><?php echo (int)$r['user_id']; ?></td>
                  <td><?php echo h((string)$r['purpose']); ?></td>
                  <td><?php echo h((string)$r['expires_at']); ?></td>
                  <td><?php echo h((string)($r['used_at'] ?? '—')); ?></td>
                  <td><?php echo h((string)$r['created_at']); ?></td>
                </tr>
              <?php endforeach; ?>
            </table>
          <?php endif; ?>

          <div class="mini" style="margin-top:10px;">
            If OTP emails aren’t sending reliably, the sending code is in <b>auth.php → start_2fa_email()</b>.
            It uses PHP’s <b>mail()</b>, which depends on your hosting mail configuration.
          </div>
        </div>

      <?php else: /* audit */ ?>
        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Admin Audit Log</b></div>
          <?php if (!$auditRows): ?>
            <div class="histitem" style="margin-top:10px;">
              No audit records (or admin_audit_log table not found).
            </div>
          <?php else: ?>
            <table class="table" style="margin-top:10px;">
              <tr>
                <th>ID</th><th>When</th><th>Admin</th><th>Action</th><th>Target</th><th>IP</th><th>Details</th>
              </tr>
              <?php foreach ($auditRows as $r): ?>
                <tr>
                  <td><?php echo (int)$r['id']; ?></td>
                  <td><?php echo h((string)$r['created_at']); ?></td>
                  <td><?php echo (int)$r['admin_id']; ?></td>
                  <td><?php echo h((string)$r['action']); ?></td>
                  <td><?php echo h((string)($r['target_user_id'] ?? '—')); ?></td>
                  <td><?php echo h((string)($r['ip'] ?? '')); ?></td>
                  <td style="max-width:420px; white-space:pre-wrap; word-break:break-word;">
                    <?php echo h((string)($r['details_json'] ?? '')); ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </table>
          <?php endif; ?>

          <div class="mini" style="margin-top:10px;">
            If you want, I can provide the exact SQL to create <b>admin_audit_log</b> (recommended) and we’ll keep logs permanently.
          </div>
        </div>
      <?php endif; ?>

      <?php if (!$selected): ?>
        <div class="dangerZone" style="margin-top:12px;">
          <b>Tip:</b> Select a user on the left to enable actions.
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
