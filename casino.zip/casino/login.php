<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/db.php';

session_boot();
ensure_csrf();

const TRUST_COOKIE_NAME = 'FM3_TRUSTED_DEVICE';
const TRUST_DAYS = 30;

// ---- Helpers ----
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function client_ip(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? ''); }
function user_agent(): string { return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255); }

function audit_log(?int $actorId, string $action, ?int $targetId = null, array $meta = []): void {
  try {
    $pdo = db();
    $pdo->prepare("
      INSERT INTO admin_audit_log (actor_user_id, action, target_user_id, ip, user_agent, meta_json)
      VALUES (?, ?, ?, ?, ?, ?)
    ")->execute([
      $actorId,
      $action,
      $targetId,
      client_ip(),
      user_agent(),
      $meta ? json_encode($meta, JSON_UNESCAPED_SLASHES) : null
    ]);
  } catch (Throwable $e) {
    // best-effort only; don't break login if audit table missing
  }
}

function trusted_cookie_set(string $selector, string $validator, int $days = TRUST_DAYS): void {
  $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  setcookie(TRUST_COOKIE_NAME, $selector . ':' . $validator, [
    'expires' => time() + ($days * 86400),
    'path' => '/casino',
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
}

function trusted_cookie_clear(): void {
  $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  setcookie(TRUST_COOKIE_NAME, '', [
    'expires' => time() - 3600,
    'path' => '/casino',
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
}

function trusted_device_issue(int $userId): void {
  // selector: public identifier, validator: secret stored only in cookie; DB stores hash(validator)
  $selector = bin2hex(random_bytes(12));   // 24 chars
  $validator = bin2hex(random_bytes(24));  // 48 chars
  $validatorHash = hash('sha256', $validator);

  $expires = (new DateTimeImmutable('now'))->modify('+' . TRUST_DAYS . ' days')->format('Y-m-d H:i:s');

  $pdo = db();
  $pdo->prepare("
    INSERT INTO trusted_devices (user_id, selector, validator_hash, user_agent, ip, expires_at)
    VALUES (?, ?, ?, ?, ?, ?)
  ")->execute([$userId, $selector, $validatorHash, user_agent(), client_ip(), $expires]);

  trusted_cookie_set($selector, $validator, TRUST_DAYS);
  audit_log($userId, 'trusted_device_issued', $userId, ['selector' => $selector, 'expires' => $expires]);
}

function trusted_device_valid_for_user(int $userId): bool {
  if (empty($_COOKIE[TRUST_COOKIE_NAME])) return false;

  $raw = (string)$_COOKIE[TRUST_COOKIE_NAME];
  if (!str_contains($raw, ':')) return false;

  [$selector, $validator] = explode(':', $raw, 2);
  $selector = trim($selector);
  $validator = trim($validator);

  if ($selector === '' || $validator === '') return false;
  if (!preg_match('/^[a-f0-9]{24}$/', $selector)) return false;

  try {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT * FROM trusted_devices
      WHERE user_id=? AND selector=? AND revoked_at IS NULL
      LIMIT 1
    ");
    $st->execute([$userId, $selector]);
    $row = $st->fetch();
    if (!$row) return false;

    // Expired?
    $exp = new DateTimeImmutable((string)$row['expires_at']);
    if ($exp < new DateTimeImmutable('now')) return false;

    $calc = hash('sha256', $validator);
    if (!hash_equals((string)$row['validator_hash'], $calc)) {
      // token mismatch – clear cookie defensively
      trusted_cookie_clear();
      audit_log($userId, 'trusted_device_invalid', $userId, ['selector' => $selector]);
      return false;
    }

    // Mark last used
    $pdo->prepare("UPDATE trusted_devices SET last_used_at=NOW(), ip=?, user_agent=? WHERE id=?")
        ->execute([client_ip(), user_agent(), (int)$row['id']]);

    audit_log($userId, 'trusted_device_used', $userId, ['selector' => $selector]);
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

// If already logged in, go to hub
$cu = current_user();
if ($cu) {
  header('Location: casino.php');
  exit;
}

// One-time "registered successfully" message from registration
$registeredEmail = null;
if (isset($_SESSION['register_success_email'])) {
  $registeredEmail = (string)$_SESSION['register_success_email'];
  unset($_SESSION['register_success_email']);
}

// Pending 2FA state
$pendingId = isset($_SESSION['pending_2fa_user_id']) ? (int)$_SESSION['pending_2fa_user_id'] : null;
$pendingEmail = isset($_SESSION['pending_2fa_email']) ? (string)$_SESSION['pending_2fa_email'] : null;

$error = '';
$info = '';
$showOtp = ($pendingId !== null);

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check((string)($_POST['csrf'] ?? ''));

    $mode = (string)($_POST['mode'] ?? '');

    if ($mode === 'login') {
      $email = normalize_email((string)($_POST['email'] ?? ''));
      $pass = (string)($_POST['password'] ?? '');

      $u = login_password($email, $pass); // throws if invalid
      $uid = (int)$u['id'];

      audit_log($uid, 'login_password_ok', $uid, ['email' => $email]);

      // If 2FA enabled, check trusted device
      $twofa = ((int)($u['twofa_enabled'] ?? 0) === 1);

      if ($twofa && !trusted_device_valid_for_user($uid)) {
        // Start OTP email
        $_SESSION['pending_2fa_user_id'] = $uid;
        $_SESSION['pending_2fa_email'] = (string)$u['email'];
        start_2fa_email($uid, (string)$u['email']);

        audit_log($uid, 'otp_sent', $uid, ['email' => (string)$u['email']]);

        $pendingId = $uid;
        $pendingEmail = (string)$u['email'];
        $showOtp = true;
        $info = "We sent a 6-digit code to " . h((string)$u['email']) . ".";
      } else {
        // No 2FA required (or trusted device valid)
        establish_session($uid);
        audit_log($uid, 'login_success', $uid, ['trusted' => $twofa ? true : false]);

        header('Location: casino.php');
        exit;
      }
    }

    if ($mode === 'verify_otp') {
      if (!$pendingId || !$pendingEmail) throw new Exception("No active login challenge. Try logging in again.");

      $code = (string)($_POST['code'] ?? '');
      verify_2fa($pendingId, $code);

      audit_log($pendingId, 'otp_verified_ok', $pendingId);

      // Clear pending state before creating session
      unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_email']);

      establish_session($pendingId);
      audit_log($pendingId, 'login_success', $pendingId, ['via' => 'otp']);

      // Remember device checkbox
      $remember = isset($_POST['remember_device']) && (string)$_POST['remember_device'] === '1';
      if ($remember) {
        trusted_device_issue($pendingId);
      } else {
        trusted_cookie_clear();
      }

      header('Location: casino.php');
      exit;
    }

    if ($mode === 'resend_otp') {
      if (!$pendingId || !$pendingEmail) throw new Exception("No active login challenge. Try logging in again.");
      start_2fa_email($pendingId, $pendingEmail);
      audit_log($pendingId, 'otp_resent', $pendingId, ['email' => $pendingEmail]);
      $info = "We sent a new code to " . h($pendingEmail) . ".";
      $showOtp = true;
    }

  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}

// Prefill email
$prefillEmail = (string)($_POST['email'] ?? $registeredEmail ?? '');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Login</title>
  <link rel="stylesheet" href="style.css"/>
  <style>
    .authWrap{ max-width: 520px; margin: 0 auto; }
    .field{ display:grid; gap:6px; margin-top:10px; }
    input[type="email"], input[type="password"], input[type="text"]{
      width:100%;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.14);
      background: rgba(0,0,0,.18);
      color: #fff;
      padding:12px 12px;
      outline:none;
    }
    .note{ opacity:.9; line-height:1.45; }
    .row{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; justify-content:space-between; margin-top:12px; }
    .msgOk{ border:1px solid rgba(120,255,170,.25); background: rgba(120,255,170,.08); padding:10px 12px; border-radius:14px; }
    .msgErr{ border:1px solid rgba(255,120,120,.25); background: rgba(255,120,120,.08); padding:10px 12px; border-radius:14px; }
    .tiny{ font-size:12px; opacity:.85; }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card authWrap">
    <div class="top">
      <div>
        <h1 style="margin:0;">🔐 Login</h1>
        <div class="sub">Secure login with email + optional verification code.</div>
      </div>
      <div class="nav">
        <a class="btn" href="index.php">Home</a>
        <a class="btn" href="register.php">Register</a>
      </div>
    </div>

    <?php if ($registeredEmail): ?>
      <div class="msgOk" style="margin-top:12px;">
        ✅ Registration successful for <b><?php echo h($registeredEmail); ?></b>. You can log in now.
      </div>
    <?php endif; ?>

    <?php if ($info): ?>
      <div class="msgOk" style="margin-top:12px;"><?php echo h($info); ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="msgErr" style="margin-top:12px;"><?php echo h($error); ?></div>
    <?php endif; ?>

    <?php if (!$showOtp): ?>
      <form method="post" style="margin-top:14px;">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"/>
        <input type="hidden" name="mode" value="login"/>

        <div class="field">
          <label class="tiny">Email</label>
          <input name="email" type="email" autocomplete="email" required
                 placeholder="you@example.com"
                 value="<?php echo h($prefillEmail); ?>"/>
        </div>

        <div class="field">
          <label class="tiny">Password</label>
          <input name="password" type="password" autocomplete="current-password" required
                 placeholder="Your password"/>
        </div>

        <div class="row">
          <button class="btn" type="submit">Login</button>
                    <a class="btn secondary" href="forgot.php">Forgot Password</a>

          <a class="btn secondary" href="register.php">Create account</a>
        </div>

        <div class="note tiny" style="margin-top:12px;">
          Tip: If you don't see the verification email, check spam/junk. (We’ll improve deliverability next.)
        </div>
      </form>
    <?php else: ?>
      <form method="post" style="margin-top:14px;">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"/>
        <input type="hidden" name="mode" value="verify_otp"/>

        <div class="note">
          Enter the <b>6-digit</b> code sent to <b><?php echo h((string)$pendingEmail); ?></b>.
        </div>

        <div class="field">
          <label class="tiny">Verification Code</label>
          <input name="code" type="text" inputmode="numeric" pattern="\d{6}" maxlength="6"
                 autocomplete="one-time-code" required placeholder="123456"/>
        </div>

        <div class="row" style="margin-top:10px;">
          <label class="pill" style="cursor:pointer;">
            <input type="checkbox" name="remember_device" value="1"/>
            Remember this device for <?php echo (int)TRUST_DAYS; ?> days
          </label>
        </div>

        <div class="row">
          <button class="btn" type="submit">Verify & Enter Casino</button>
        </div>
      </form>

      <form method="post" style="margin-top:10px;">
        <input type="hidden" name="csrf" value="<?php echo h(csrf_token()); ?>"/>
        <input type="hidden" name="mode" value="resend_otp"/>
        <button class="btn secondary" type="submit">Resend code</button>
        <a class="btn secondary" href="login.php" style="margin-left:8px;">Start over</a>
      </form>
    <?php endif; ?>

  </div>
</div>
</body>
</html>
