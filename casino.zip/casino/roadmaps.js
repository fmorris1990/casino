// /casino/roadmaps.js
// Builds casino-style roadmaps from baccarat history (Player/Banker/Tie).

const Roadmaps = (() => {
  const ROWS = 6;     // typical road row count
  const COLS = 24;    // visible columns (scrollable container can show more)

  function normalizeOutcome(item) {
    // expect item.outcome in {"player","banker","tie"}
    const o = (item && item.outcome) ? String(item.outcome) : "";
    if (o === "player" || o === "banker" || o === "tie") return o;

    // fallback: infer from label (older history)
    const label = String(item?.label || "").toLowerCase();
    if (label.includes("player")) return "player";
    if (label.includes("banker")) return "banker";
    if (label.includes("tie")) return "tie";
    return "";
  }

  // ===== Bead Plate =====
  // Fill left->right, top->bottom (or you can swap)
  function buildBeadPlate(history, rows = ROWS, cols = 12) {
    const grid = Array.from({ length: rows }, () => Array.from({ length: cols }, () => null));
    const outcomes = history.map(normalizeOutcome).filter(Boolean);

    for (let i = 0; i < Math.min(outcomes.length, rows * cols); i++) {
      const r = Math.floor(i / cols);
      const c = i % cols;
      grid[r][c] = { outcome: outcomes[i] };
    }
    return { grid, rows, cols };
  }

  // ===== Big Road (simplified but intuitive) =====
  // Rules:
  // - Ties do not advance position; they "stack" on current cell (tieCount)
  // - Player/Banker:
  //   - Same as last non-tie: go down if space, else go right
  //   - Change: go to next column top row
  function buildBigRoad(history, rows = ROWS, cols = COLS) {
    const outcomes = history.map(normalizeOutcome).filter(Boolean);

    const grid = Array.from({ length: rows }, () => Array.from({ length: cols }, () => null));

    let col = 0;
    let row = 0;
    let last = null;           // last non-tie outcome
    let lastCell = null;       // pointer to current cell
    let maxColUsed = 0;

    for (const o of outcomes) {
      if (o === "tie") {
        // Tie marks current cell
        if (lastCell) {
          lastCell.tieCount = (lastCell.tieCount || 0) + 1;
        } else {
          // If the shoe begins with ties, put them at 0,0 as neutral tie marker
          if (!grid[0][0]) grid[0][0] = { outcome: "tie", tieCount: 1 };
          else grid[0][0].tieCount = (grid[0][0].tieCount || 0) + 1;
          lastCell = grid[0][0];
        }
        continue;
      }

      if (last === null) {
        // first non-tie
        col = 0; row = 0;
        grid[row][col] = { outcome: o, tieCount: 0 };
        lastCell = grid[row][col];
        last = o;
        maxColUsed = Math.max(maxColUsed, col);
        continue;
      }

      if (o === last) {
        // continue streak
        const nextRow = row + 1;

        if (nextRow < rows && !grid[nextRow][col]) {
          row = nextRow;
        } else {
          // can't go down -> move right
          col = Math.min(cols - 1, col + 1);
          // find first free row in this column (prefer same row if open, else scan)
          let placed = false;
          for (let rr = row; rr >= 0; rr--) {
            if (!grid[rr][col]) { row = rr; placed = true; break; }
          }
          if (!placed) {
            for (let rr = 0; rr < rows; rr++) {
              if (!grid[rr][col]) { row = rr; placed = true; break; }
            }
          }
        }

        if (!grid[row][col]) grid[row][col] = { outcome: o, tieCount: 0 };
        lastCell = grid[row][col];
        maxColUsed = Math.max(maxColUsed, col);
      } else {
        // streak changed -> new column top
        col = Math.min(cols - 1, col + 1);
        row = 0;

        // if occupied (rare in long sessions), shift right until open
        while (col < cols && grid[row][col]) col++;
        if (col >= cols) break;

        grid[row][col] = { outcome: o, tieCount: 0 };
        lastCell = grid[row][col];
        last = o;
        maxColUsed = Math.max(maxColUsed, col);
      }
    }

    return { grid, rows, cols, maxColUsed };
  }

  function outcomeClass(outcome) {
    if (outcome === "player") return "p";
    if (outcome === "banker") return "b";
    if (outcome === "tie") return "t";
    return "";
  }

  function renderBeadPlate(container, model) {
    const { grid, rows, cols } = model;
    container.style.setProperty("--rm-cols", String(cols));
    container.innerHTML = "";

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = document.createElement("div");
        cell.className = "rm-cell";
        const v = grid[r][c];
        if (v) {
          const dot = document.createElement("div");
          dot.className = `rm-dot ${outcomeClass(v.outcome)}`;
          cell.appendChild(dot);
        }
        container.appendChild(cell);
      }
    }
  }

  function renderBigRoad(container, model) {
    const { grid, rows, cols } = model;
    container.style.setProperty("--rm-cols", String(cols));
    container.innerHTML = "";

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = document.createElement("div");
        cell.className = "rm-cell rm-bigcell";
        const v = grid[r][c];
        if (v) {
          const dot = document.createElement("div");
          dot.className = `rm-dot ${outcomeClass(v.outcome)}`;
          cell.appendChild(dot);

          if ((v.tieCount || 0) > 0) {
            const badge = document.createElement("div");
            badge.className = "rm-tie-badge";
            badge.textContent = String(v.tieCount);
            cell.appendChild(badge);
          }
        }
        container.appendChild(cell);
      }
    }
  }

  function updateFromBacHistory(history, opts = {}) {
    // history is expected newest-first in your backend; roadmaps should be oldest-first
    const ordered = [...(history || [])].slice().reverse();

    const bead = buildBeadPlate(ordered, opts.beadRows || 6, opts.beadCols || 12);
    const big  = buildBigRoad(ordered, 6, opts.bigCols || 24);

    return { bead, big };
  }

  return {
    updateFromBacHistory,
    renderBeadPlate,
    renderBigRoad,
  };
})();
