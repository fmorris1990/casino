<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

ensure_csrf();
$err = '';
$pending = (int)($_SESSION['pending_2fa'] ?? 0);

if ($pending <= 0) {
  header('Location: login.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);
    $code = (string)($_POST['code'] ?? '');
    verify_2fa($pending, $code);
    establish_session($pending);
    unset($_SESSION['pending_2fa']);
    header('Location: index.php');
    exit;
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}
?>
<!doctype html>
<html><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Verify</title>
<link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>2FA Verification</h1>
    <div class="sub">Enter the 6-digit code sent to your email.</div>

    <?php if($err): ?>
      <div class="msg"><div class="err"><?php echo htmlspecialchars($err); ?></div></div>
    <?php endif; ?>

    <form method="post" class="box" style="margin-top:12px;">
      <input type="hidden" name="csrf" value="<?php echo htmlspecialchars(csrf_token()); ?>"/>
      <div class="small"><b>Code</b></div>
      <input name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" required
             style="margin-top:6px; width:100%; padding:10px; border-radius:12px; border:1px solid rgba(255,255,255,.12); background:rgba(0,0,0,.12); color:#fff; font-size:18px; letter-spacing:3px;"/>
      <div style="margin-top:12px; display:flex; gap:10px;">
        <button class="btn" type="submit">Verify</button>
        <a class="btn secondary" href="login.php">Restart</a>
      </div>
    </form>
  </div>
</div>
</body></html>
