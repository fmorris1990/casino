<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
$u = require_admin(); // redirects / blocks if not admin
