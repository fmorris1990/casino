<?php
declare(strict_types=1);
require __DIR__ . '/common.php'; // requires login
$csrf = $_SESSION['csrf'];
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Tutorial</title>
  <link rel="stylesheet" href="style.css"/>
  <style>
    .grid2{ display:grid; grid-template-columns: 1fr 1fr; gap:14px; }
    @media (max-width: 980px){ .grid2{ grid-template-columns: 1fr; } }

    .toc a{ display:block; padding:10px 12px; border-radius:14px; border:1px solid rgba(255,255,255,.10);
      background: rgba(0,0,0,.12); text-decoration:none; color:inherit; }
    .toc a:hover{ border-color: rgba(255,255,255,.18); }

    .section{ scroll-margin-top: 90px; }
    .kicker{ font-size:12px; opacity:.85; letter-spacing:.2px; margin-top:4px; }
    .lead{ opacity:.92; line-height:1.55; margin-top:8px; }

    .callout{
      border:1px solid rgba(255,255,255,.12);
      background: rgba(0,0,0,.14);
      border-radius:16px;
      padding:12px;
      line-height:1.5;
    }

    .table{
      width:100%;
      border-collapse:separate;
      border-spacing:0;
      overflow:hidden;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.10);
      background: rgba(0,0,0,.10);
    }
    .table th, .table td{
      padding:10px 12px;
      border-bottom:1px solid rgba(255,255,255,.08);
      font-size:13px;
      vertical-align:top;
    }
    .table th{ text-align:left; font-weight:900; background: rgba(255,255,255,.05); }
    .table tr:last-child td{ border-bottom:none; }

    .chips{ display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
    .chip{
      display:inline-flex; align-items:center; gap:8px;
      padding:8px 10px;
      border-radius:999px;
      border:1px solid rgba(255,255,255,.12);
      background: rgba(255,255,255,.05);
      font-size:12px;
      opacity:.95;
    }

    /* Card visuals (same style you’ve been using) */
    .cards{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; padding-top:6px; }
    .cardFace{
      width:64px; height:88px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.14);
      background: linear-gradient(180deg, rgba(255,255,255,.12), rgba(0,0,0,.18));
      box-shadow: 0 10px 26px rgba(0,0,0,.25);
      position:relative;
      overflow:hidden;
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      padding:8px;
    }
    .cardFace::after{
      content:'';
      position:absolute; inset:0;
      background: radial-gradient(circle at 30% 30%, rgba(120,220,255,.16), transparent 50%),
                  radial-gradient(circle at 70% 80%, rgba(255,120,220,.12), transparent 55%);
      pointer-events:none;
    }
    .rank{ position:relative; z-index:2; font-weight:950; font-size:16px; line-height:1; }
    .suit{ position:relative; z-index:2; font-size:18px; }
    .pip{
      position:absolute; left:50%; top:50%;
      transform: translate(-50%,-50%);
      font-size:28px;
      opacity:.28;
      z-index:1;
      filter: blur(.2px);
    }
    .red{ color:#ff6b6b; }
    .black{ color:#eaeaea; }

    .exampleGrid{ display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-top:10px; }
    @media (max-width: 820px){ .exampleGrid{ grid-template-columns:1fr; } }

    /* Slots visuals (tutorial only) */
    .reels{ display:flex; gap:12px; align-items:center; justify-content:center; padding:12px; }
    .reel{
      width:86px; height:86px; border-radius:18px;
      border:1px solid rgba(255,255,255,.12);
      background: rgba(0,0,0,.16);
      display:flex; align-items:center; justify-content:center;
      font-size:42px; font-weight:900;
      box-shadow: 0 10px 26px rgba(0,0,0,.25);
      position:relative;
      overflow:hidden;
    }

    .wheelStage{ display:flex; justify-content:center; position:relative; margin-top:10px; }
    .wheelRing{
      padding:10px;
      border-radius:999px;
      background: radial-gradient(circle at 30% 20%, rgba(120,220,255,.20), transparent 45%),
                  radial-gradient(circle at 70% 70%, rgba(255,120,220,.18), transparent 45%),
                  rgba(0,0,0,.10);
      border:1px solid rgba(255,255,255,.12);
      box-shadow: 0 14px 32px rgba(0,0,0,.28);
      position:relative;
      overflow:hidden;
    }
    .pointer{
      width:0;height:0;
      border-left:10px solid transparent;
      border-right:10px solid transparent;
      border-bottom:18px solid rgba(255,255,255,.92);
      position:absolute; top:-2px; left:calc(50% - 10px);
      filter: drop-shadow(0 4px 8px rgba(0,0,0,.35));
      z-index:3;
    }
    .wheel{
      width:210px; height:210px; border-radius:50%;
      border:2px solid rgba(255,255,255,.18);
      background: rgba(0,0,0,.14);
      position:relative;
      overflow:hidden;
    }
    .sliceLabel{
      position:absolute; left:50%; top:50%;
      transform-origin: 0 0;
      font-weight:950;
      font-size:12px;
      opacity:.95;
      white-space:nowrap;
      text-shadow: 0 0 14px rgba(0,0,0,.35);
    }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🎓 Casino Tutorial</h1>
        <div class="sub">Learn each game, payouts, and see examples with the same visuals used in play.</div>
      </div>
      <div class="nav">
        <a class="btn" href="casino.php">🏠 Hub</a>
        <a class="btn" href="lottery.php">🎰 Slots</a>
        <a class="btn" href="blackjack.php">🂡 Blackjack</a>
        <a class="btn" href="baccarat.php">🎴 Baccarat</a>
        <a class="btn active" href="tutorial.php">🎓 Tutorial</a>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="pillrow" style="margin-top:12px;">
      <div class="pill">Credits: <strong id="m-credits">—</strong></div>
      <div class="pill">Session high: <strong id="m-high">—</strong></div>
      <div class="pill">Shoe: <strong id="m-shoe">—</strong></div>
    </div>
  </div>

  <div class="grid2" style="margin-top:14px;">
    <div class="card toc">
      <h2 style="margin:0; font-size:18px;">Contents</h2>
      <div class="kicker">Jump to any section</div>

      <div style="display:grid; gap:10px; margin-top:12px;">
        <a href="#basics">✅ Basics: Credits, Bets, Shoes</a>
        <a href="#slots">🎰 High Roller Slots + Bonus Wheel + Progressive Jackpot</a>
        <a href="#blackjack">🂡 Blackjack: Rules, Actions, Payouts</a>
        <a href="#baccarat">🎴 Baccarat: Main + Side Bets (Pairs / Perfect Pair)</a>
        <a href="#responsible">🛡️ Responsible Play + Security Notes</a>
      </div>
    </div>

    <div class="card">
      <h2 id="basics" class="section" style="margin:0; font-size:18px;">✅ Basics</h2>
      <div class="lead">
        This site is for fun with virtual credits. Your credits are tied to your account.
        The card games use a shuffled “shoe” (multiple decks) like a real casino.
      </div>

      <div class="callout" style="margin-top:12px;">
        <b>What is a “shoe”?</b><br/>
        A shoe is a combined stack of multiple decks. Cards are drawn from the shoe until a “cut point” is reached,
        then the shoe re-shuffles automatically.
        <div class="chips">
          <span class="chip">🂡 Blackjack: configurable decks (from hub)</span>
          <span class="chip">🎴 Baccarat: always 8 decks</span>
        </div>
      </div>

      <table class="table" style="margin-top:12px;">
        <tr><th>Term</th><th>Meaning</th></tr>
        <tr><td><b>Wager</b></td><td>The amount you stake on a hand/spin.</td></tr>
        <tr><td><b>Payout</b></td><td>What you receive back (often includes your original stake).</td></tr>
        <tr><td><b>Profit</b></td><td>Payout minus your original stake.</td></tr>
      </table>
    </div>
  </div>

  <!-- SLOTS -->
  <div class="card" style="margin-top:14px;">
    <h2 id="slots" class="section" style="margin:0; font-size:18px;">🎰 High Roller Slots</h2>
    <div class="kicker">Two bet sizes • Rare bonus • Progressive jackpot only via bonus wheel on max bet</div>

    <div class="lead">
      Slots has only two bet options: <b>1 credit</b> or <b>2 credits (VIP / max)</b>.
      Credits have a fixed denomination (example: 1 credit = 500).
    </div>

    <div class="callout" style="margin-top:12px;">
      <b>Bonus Wheel (VIP)</b><br/>
      The bonus wheel only triggers when you hit the <b>bonus feature</b> (rare) while betting <b>2 credits</b>.
      When triggered, the wheel pays a multiplier of your bet.
      <div style="margin-top:8px;">
        ✅ <b>Minimum bonus payout:</b> 5× the bet<br/>
        🏆 <b>Maximum bonus payout:</b> the full progressive jackpot (only way to win it)
      </div>
    </div>

    <div class="exampleGrid">
      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Example Spin (visual)</b>
        <div class="reels" aria-label="Slots Example Reels">
          <div class="reel">⭐</div>
          <div class="reel">⭐</div>
          <div class="reel">⭐</div>
        </div>
        <div class="small" style="opacity:.9;">
          Example: three-of-a-kind can pay base winnings (depends on your symbol table).<br/>
          If you also trigger the <b>bonus feature</b> on <b>VIP (2 credits)</b>, the wheel animation plays.
        </div>
      </div>

      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Bonus Wheel (visual)</b>
        <div class="wheelStage">
          <div class="pointer"></div>
          <div class="wheelRing">
            <div class="wheel" id="wheelDemo"></div>
          </div>
        </div>
        <div class="small" style="opacity:.9; margin-top:10px;">
          Wheel segments are examples. Your live game uses server logic to pick the result fairly.
        </div>
      </div>
    </div>

    <table class="table" style="margin-top:12px;">
      <tr><th>Feature</th><th>How it works</th></tr>
      <tr>
        <td><b>Bet sizes</b></td>
        <td>Only 1 credit or 2 credits (VIP / max bet).</td>
      </tr>
      <tr>
        <td><b>Progressive jackpot</b></td>
        <td>Increases as players bet. Can only be won if the bonus wheel triggers on VIP and lands on jackpot.</td>
      </tr>
      <tr>
        <td><b>Bonus wheel trigger</b></td>
        <td>Rare feature. When it triggers, wheel minimum payout is 5× bet and max is jackpot.</td>
      </tr>
    </table>
  </div>

  <!-- BLACKJACK -->
  <div class="card" style="margin-top:14px;">
    <h2 id="blackjack" class="section" style="margin:0; font-size:18px;">🂡 Blackjack</h2>
    <div class="kicker">Try to get as close to 21 as possible without going over</div>

    <div class="lead">
      Blackjack is played against the dealer. You start with 2 cards, dealer has 2 cards (one typically treated as “up card”).
      Face cards are worth 10, Aces are worth 1 or 11.
    </div>

    <table class="table" style="margin-top:12px;">
      <tr><th>Action</th><th>What it does</th><th>When you should consider it</th></tr>
      <tr><td><b>Hit</b></td><td>Take another card.</td><td>When your total is low and you want to improve.</td></tr>
      <tr><td><b>Stand</b></td><td>Keep your total and end your turn.</td><td>When you think another card risks busting.</td></tr>
      <tr><td><b>Double</b></td><td>Double your bet, take exactly one card, then stand.</td><td>Strong starting totals (often 9–11), depends on dealer up card.</td></tr>
      <tr><td><b>Split</b></td><td>If your first 2 cards match, split into 2 hands (costs another bet).</td><td>When splitting improves odds (ex: A,A or 8,8 often).</td></tr>
      <tr><td><b>Insurance</b></td><td>Optional side bet when dealer shows Ace (pays if dealer has blackjack).</td><td>Typically not favorable long-term, but allowed as an option.</td></tr>
    </table>

    <div class="callout" style="margin-top:12px;">
      <b>Payouts (typical)</b><br/>
      • Win: 1:1 (you receive stake + profit = 2× bet total back)<br/>
      • Blackjack (A + 10-value): 3:2 (receive 2.5× bet total back)<br/>
      • Push (tie): stake returned
    </div>

    <div class="exampleGrid" style="margin-top:12px;">
      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Example Hand</b>
        <div class="small" style="margin-top:6px; opacity:.9;">Player: 10 + 6 (total 16). Dealer shows 10.</div>
        <div class="cards" style="margin-top:8px;">
          <div class="cardFace black"><div class="rank">10</div><div class="suit">♠</div><div class="pip">♠</div></div>
          <div class="cardFace red"><div class="rank">6</div><div class="suit">♥</div><div class="pip">♥</div></div>
        </div>
        <div class="small" style="margin-top:10px; opacity:.9;">
          Common decision: standing is often safer than hitting on 16 vs 10, but depends on rules/strategy.
        </div>
      </div>

      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Dealer Example</b>
        <div class="small" style="margin-top:6px; opacity:.9;">Dealer: 10 + 7 (total 17) stands.</div>
        <div class="cards" style="margin-top:8px;">
          <div class="cardFace black"><div class="rank">10</div><div class="suit">♣</div><div class="pip">♣</div></div>
          <div class="cardFace black"><div class="rank">7</div><div class="suit">♠</div><div class="pip">♠</div></div>
        </div>
        <div class="small" style="margin-top:10px; opacity:.9;">
          Dealer must hit until at least 17 (soft 17 behavior depends on the toggle).
        </div>
      </div>
    </div>
  </div>

  <!-- BACCARAT -->
  <div class="card" style="margin-top:14px;">
    <h2 id="baccarat" class="section" style="margin:0; font-size:18px;">🎴 Baccarat</h2>
    <div class="kicker">Bet Player / Banker / Tie + optional side bets</div>

    <div class="lead">
      Baccarat totals are calculated differently than most card games:
      card values are 0–9 and totals only keep the last digit (mod 10).
    </div>

    <table class="table" style="margin-top:12px;">
      <tr><th>Card</th><th>Value</th></tr>
      <tr><td>A</td><td>1</td></tr>
      <tr><td>2–9</td><td>Face value</td></tr>
      <tr><td>10 / J / Q / K</td><td>0</td></tr>
    </table>

    <div class="callout" style="margin-top:12px;">
      <b>Main Bet Payouts</b><br/>
      • Player wins: pays 1:1<br/>
      • Banker wins: pays 0.95:1 (5% commission)<br/>
      • Tie: pays 8:1 (returns 9× total including stake)<br/>
      <div style="margin-top:8px;">
        <b>Side Bets (common)</b><br/>
        • Player Pair: 11:1 (first 2 player cards same rank)<br/>
        • Banker Pair: 11:1 (first 2 banker cards same rank)<br/>
        • Perfect Pair: 25:1 (suited pair on either side)
      </div>
    </div>

    <div class="exampleGrid" style="margin-top:12px;">
      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Example Deal (visual)</b>
        <div class="small" style="margin-top:6px; opacity:.9;">Player: 7 + K → 7. Banker: 4 + 5 → 9.</div>

        <div class="small" style="margin-top:10px;"><b>Player</b></div>
        <div class="cards" style="margin-top:6px;">
          <div class="cardFace red"><div class="rank">7</div><div class="suit">♦</div><div class="pip">♦</div></div>
          <div class="cardFace black"><div class="rank">K</div><div class="suit">♠</div><div class="pip">♠</div></div>
        </div>

        <div class="small" style="margin-top:10px;"><b>Banker</b></div>
        <div class="cards" style="margin-top:6px;">
          <div class="cardFace black"><div class="rank">4</div><div class="suit">♣</div><div class="pip">♣</div></div>
          <div class="cardFace red"><div class="rank">5</div><div class="suit">♥</div><div class="pip">♥</div></div>
        </div>

        <div class="small" style="margin-top:10px; opacity:.9;">
          Banker wins 9 vs 7. Banker bet pays with commission.
        </div>
      </div>

      <div class="tableBox" style="border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.12); border-radius:16px; padding:12px;">
        <b>Natural (automatic end)</b>
        <div class="small" style="margin-top:6px; opacity:.9;">
          If either side totals <b>8 or 9</b> on the first 2 cards, the hand is a <b>natural</b> and no third cards are drawn.
        </div>
        <div class="chips">
          <span class="chip">Natural 8 or 9 ends the hand</span>
          <span class="chip">Third card rules apply otherwise</span>
          <span class="chip">Baccarat always uses 8 decks here</span>
        </div>
      </div>
    </div>
  </div>

  <!-- RESPONSIBLE -->
  <div class="card" style="margin-top:14px;">
    <h2 id="responsible" class="section" style="margin:0; font-size:18px;">🛡️ Responsible Play & Account Safety</h2>

    <div class="lead">
      This platform is designed for entertainment using virtual credits.
      Please play responsibly and take steps to protect your account.
    </div>

    <div class="callout" style="margin-top:12px;">
      <b>Responsible Play</b><br/>
      • Play for fun, not obligation<br/>
      • Take breaks if gameplay stops being enjoyable<br/>
      • Set personal limits for time and credits<br/>
      • Remember: outcomes are random and past results do not affect future hands
    </div>

    <div class="callout" style="margin-top:12px;">
      <b>Account Safety Tips</b><br/>
      • Use a strong, unique password that you don’t use elsewhere<br/>
      • Never share your login or verification codes with anyone<br/>
      • Log out when using shared or public devices<br/>
      • Verify your email address so you can recover access if needed
    </div>

    <div class="callout" style="margin-top:12px;">
      <b>Fair Play & Transparency</b><br/>
      • All games use server-side logic for fairness<br/>
      • Card games use shuffled multi-deck shoes similar to real casinos<br/>
      • Slot outcomes, bonus wheels, and jackpots are generated fairly and independently
    </div>

    <div class="small" style="opacity:.85; margin-top:10px;">
      If you ever believe your account is compromised, stop playing immediately and contact support.
    </div>
  </div>



</div>

<script>
const CSRF = <?php echo json_encode($csrf); ?>;

async function api(op, payload={}){
  const res = await fetch('api.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({op, csrf: CSRF, ...payload})
  });
  const data = await res.json();
  if(!res.ok || !data.ok) throw new Error(data?.error || 'Request failed');
  return data;
}
function money(n){ return String(Math.floor(Number(n||0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function renderMeta(m){
  document.getElementById('m-credits').textContent = money(m.credits);
  document.getElementById('m-high').textContent = money(m.sessionHighCredits ?? m.credits);
  const s=m.shoe;
  document.getElementById('m-shoe').textContent = `${s.remaining}/${s.totalCards} left • shuffles ${s.shuffles}`;
}

/* Demo wheel visuals only (no gameplay logic here) */
(function buildWheelDemo(){
  const WHEEL = [
    {label:'x5'}, {label:'x8'}, {label:'x10'}, {label:'x12'},
    {label:'x15'}, {label:'x20'}, {label:'JACKPOT'}
  ];
  const wheel = document.getElementById('wheelDemo');
  if(!wheel) return;
  wheel.innerHTML = '';
  const n = WHEEL.length;
  for(let i=0;i<n;i++){
    const seg = WHEEL[i];
    const a = (i*(360/n)) - 90;
    const lab = document.createElement('div');
    lab.className = 'sliceLabel';
    lab.textContent = seg.label;
    lab.style.transform = `rotate(${a}deg) translate(14px, -6px)`;
    wheel.appendChild(lab);
  }
})();

api('meta_get').then(d=>renderMeta(d.meta)).catch(()=>{});
</script>

<script>
(function(){
  const IDLE_LIMIT_MS = 20 * 60 * 1000;   // 20 minutes total
  const WARN_AT_MS    = 18 * 60 * 1000;   // warn at 18 minutes
  let tLast = Date.now();
  let warned = false;

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position:fixed; inset:0; display:none; align-items:center; justify-content:center;
    background:rgba(0,0,0,.55); backdrop-filter: blur(4px); z-index:99999;
  `;
  overlay.innerHTML = `
    <div style="width:min(520px,92vw); border-radius:18px; border:1px solid rgba(255,255,255,.18);
      background:rgba(12,12,16,.88); padding:16px; box-shadow:0 18px 60px rgba(0,0,0,.55);">
      <div style="font-weight:900; font-size:18px;">You’re about to be signed out</div>
      <div style="opacity:.9; margin-top:8px; line-height:1.45;">
        For your security, we log you out after inactivity. Click below to stay signed in.
      </div>
      <div style="margin-top:14px; display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;">
        <button id="stayBtn" class="btn">Stay signed in</button>
        <a class="btn secondary" href="logout.php">Logout now</a>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  function touch(){ tLast = Date.now(); warned = false; overlay.style.display='none'; }
  ['click','keydown','mousemove','touchstart','scroll'].forEach(ev => window.addEventListener(ev, touch, {passive:true}));

  // This pings server to refresh session timer (you’ll add api op=ping in api.php)
  async function ping(){
    try{
      if (typeof CSRF === 'undefined') return touch();
      await fetch('api.php', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({op:'ping', csrf: CSRF})
      });
    } catch(e) {}
    touch();
  }
  overlay.querySelector('#stayBtn').addEventListener('click', ping);

  setInterval(()=>{
    const idle = Date.now() - tLast;
    if (!warned && idle >= WARN_AT_MS && idle < IDLE_LIMIT_MS){
      warned = true;
      overlay.style.display='flex';
    }
    if (idle >= IDLE_LIMIT_MS){
      window.location.href = 'logout.php';
    }
  }, 1000);
})();
</script>


</body>
</html>
