<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
  @ini_set('session.cookie_path', '/');
  @session_start();
}

$u = function_exists('current_user') ? current_user() : null;
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>FM3 Casino</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🎲 FM3 Casino</h1>
        <div class="sub">Play-for-fun casino games with virtual credits.</div>
      </div>
      <div class="nav">
        <?php if ($u): ?>
          <a class="btn" href="casino.php">Enter Casino</a>
          <a class="btn" href="logout.php">Logout</a>
        <?php else: ?>
          <a class="btn" href="login.php">Login</a>
          <a class="btn" href="register.php">Create Account</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="box" style="margin-top:12px;">
      <?php if ($u): ?>
        <div><b>Welcome back:</b> <?php echo htmlspecialchars((string)($u['email'] ?? '')); ?></div>
        <div class="small" style="margin-top:6px;">You’re logged in. Click “Enter Casino” to play.</div>
      <?php else: ?>
        <div><b>Welcome!</b></div>
        <div class="small" style="margin-top:6px;">
          Login to access Slots, Blackjack, and Baccarat. Your credits are tied to your account.
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>
