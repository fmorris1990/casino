<?php
declare(strict_types=1);
require __DIR__ . '/common.php'; // requires login
$csrf = $_SESSION['csrf'];
$u = current_user(); // safe; common.php already requires login
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Casino Hub</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🏠 Casino Hub</h1>
        <div class="sub">
          Welcome<?php echo $u ? (": <b>".htmlspecialchars((string)$u['email'])."</b>") : ""; ?>
          <?php if ($u && (int)($u['is_admin'] ?? 0) === 1): ?>
            <span class="tag">ADMIN</span>
          <?php endif; ?>
          <div style="margin-top:6px;">
            Credits are tied to your account. Game hands/history are kept in-session.
          </div>
        </div>
      </div>
      <div class="nav">
        <a class="btn active" href="casino.php">🏠 Hub</a>
        <a class="btn" href="lottery.php">🎰 Slots</a>
        <a class="btn" href="blackjack.php">🂡 Blackjack</a>
        <a class="btn" href="baccarat.php">🎴 Baccarat</a>
        <a class="btn" href="tutorial.php">🎓 Tutorial</a>
        <?php if ($u && (int)($u['is_admin'] ?? 0) === 1): ?>
          <a class="btn" href="admin.php">🛠 Admin</a>
        <?php endif; ?>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="pillrow" style="margin-top:12px;">
      <div class="pill">Credits: <strong id="m-credits">—</strong></div>
      <div class="pill">Session high: <strong id="m-high">—</strong></div>
      <div class="pill">Net: <strong id="m-net">—</strong></div>
      <div class="pill">Shoe: <strong id="m-shoe">—</strong></div>
    </div>

    <div class="grid" style="margin-top:14px;">
      <div class="card" style="box-shadow:none;">
        <h2 style="margin:0; font-size:18px;">🎮 Games</h2>
        <div class="sub">Pick a table and play. No ads, no external tracking.</div>

        <div class="actions" style="margin-top:12px;">
          <a class="btn" href="lottery.php">🎰 High Roller Slots</a>
          <a class="btn" href="blackjack.php">🂡 Blackjack</a>
          <a class="btn" href="baccarat.php">🎴 Baccarat</a>
        </div>

        <div class="box" style="margin-top:14px;">
          <div class="small"><b>Gameplay Options</b></div>

          <div class="actions" style="margin-top:10px;">
            <label class="pill" style="cursor:pointer;">
              <input type="checkbox" id="h17" onchange="setH17(this.checked)" />
              Dealer hits soft 17
            </label>

            <label class="pill" style="gap:10px;">
              Decks:
              <select id="decks" onchange="setDecks(this.value)">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="4">4</option>
                <option value="6" selected>6</option>
                <option value="8">8</option>
              </select>
              <span class="small">Changing decks reshuffles immediately.</span>
            </label>

            <button class="secondary danger" onclick="resetAll()">Reset Session (games)</button>
          </div>

          <div class="small" style="margin-top:10px; opacity:.9;">
            Note: Reset Session does <b>not</b> reset your DB credits—only in-session shoe + game round states.
          </div>
        </div>
      </div>

      <div class="card" style="box-shadow:none;">
        <h2 style="margin:0; font-size:18px;">📌 Status</h2>
        <div class="sub">A quick view of your shoe and settings.</div>

        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Current</b></div>
          <div class="hist" style="margin-top:10px;">
            <div class="histitem">
              <div><b>Shoe</b></div>
              <div class="small" id="shoeLine">—</div>
            </div>
            <div class="histitem">
              <div><b>Settings</b></div>
              <div class="small" id="setLine">—</div>
            </div>
          </div>
        </div>

        <div id="msg" class="msg" style="margin-top:12px;"></div>
      </div>
    </div>
  </div>
</div>

<script>
const CSRF = <?php echo json_encode($csrf); ?>;

async function api(op, payload={}){
  const res = await fetch('api.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({op, csrf: CSRF, ...payload})
  });
  const data = await res.json();
  if(!res.ok || !data.ok) throw new Error(data?.error || 'Request failed');
  return data;
}

function money(n){ return String(Math.floor(Number(n||0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function setMsg(type, text){
  document.getElementById('msg').innerHTML = text ? `<div class="${type==='err'?'err':'ok'}">${text}</div>` : '';
}

function renderMeta(m){
  document.getElementById('m-credits').textContent = money(m.credits);
  document.getElementById('m-high').textContent = money(m.sessionHighCredits ?? m.credits);
  document.getElementById('m-net').textContent = money(m.netWon ?? (m.credits - (m.startCredits||0)));

  const s = m.shoe || {};
  document.getElementById('m-shoe').textContent =
    `${s.remaining}/${s.totalCards} left • decks ${s.decks} • shuffles ${s.shuffles}`;

  document.getElementById('shoeLine').textContent =
    `Decks ${s.decks} • Remaining ${s.remaining}/${s.totalCards} • Cut at ${s.cutAtUsed} drawn • Shuffles ${s.shuffles}`;

  const h17 = !!m.settings?.dealerHitsSoft17;
  document.getElementById('h17').checked = h17;
  document.getElementById('setLine').textContent = `Dealer hits soft 17: ${h17 ? 'ON' : 'OFF'}`;

  // sync selector
  const decksSel = document.getElementById('decks');
  if(decksSel && String(decksSel.value) !== String(s.decks)){
    decksSel.value = String(s.decks);
  }
}

async function setH17(on){
  setMsg('', '');
  try{
    const d = await api('settings_set', {dealerHitsSoft17: !!on});
    renderMeta(d.meta);
    setMsg('ok', 'Settings updated.');
  } catch(e){
    setMsg('err', e.message);
  }
}

async function setDecks(v){
  setMsg('', '');
  const decks = Math.max(1, Math.min(8, Math.floor(Number(v||6))));
  try{
    const d = await api('shoe_set', {decks});
    renderMeta(d.meta);
    setMsg('ok', `Shoe reshuffled with ${decks} deck(s).`);
  } catch(e){
    setMsg('err', e.message);
  }
}

async function resetAll(){
  if(!confirm('Reset session game state (shoe + games)?')) return;
  setMsg('', '');
  try{
    const d = await api('reset_all');
    renderMeta(d.meta);
    setMsg('ok', 'Session reset complete.');
  } catch(e){
    setMsg('err', e.message);
  }
}

api('meta_get').then(d=>renderMeta(d.meta)).catch(()=>{});
</script>

<script>
(function(){
  const IDLE_LIMIT_MS = 20 * 60 * 1000;   // 20 minutes total
  const WARN_AT_MS    = 18 * 60 * 1000;   // warn at 18 minutes
  let tLast = Date.now();
  let warned = false;

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position:fixed; inset:0; display:none; align-items:center; justify-content:center;
    background:rgba(0,0,0,.55); backdrop-filter: blur(4px); z-index:99999;
  `;
  overlay.innerHTML = `
    <div style="width:min(520px,92vw); border-radius:18px; border:1px solid rgba(255,255,255,.18);
      background:rgba(12,12,16,.88); padding:16px; box-shadow:0 18px 60px rgba(0,0,0,.55);">
      <div style="font-weight:900; font-size:18px;">You’re about to be signed out</div>
      <div style="opacity:.9; margin-top:8px; line-height:1.45;">
        For your security, we log you out after inactivity. Click below to stay signed in.
      </div>
      <div style="margin-top:14px; display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;">
        <button id="stayBtn" class="btn">Stay signed in</button>
        <a class="btn secondary" href="logout.php">Logout now</a>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  function touch(){ tLast = Date.now(); warned = false; overlay.style.display='none'; }
  ['click','keydown','mousemove','touchstart','scroll'].forEach(ev => window.addEventListener(ev, touch, {passive:true}));

  // This pings server to refresh session timer (you’ll add api op=ping in api.php)
  async function ping(){
    try{
      if (typeof CSRF === 'undefined') return touch();
      await fetch('api.php', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({op:'ping', csrf: CSRF})
      });
    } catch(e) {}
    touch();
  }
  overlay.querySelector('#stayBtn').addEventListener('click', ping);

  setInterval(()=>{
    const idle = Date.now() - tLast;
    if (!warned && idle >= WARN_AT_MS && idle < IDLE_LIMIT_MS){
      warned = true;
      overlay.style.display='flex';
    }
    if (idle >= IDLE_LIMIT_MS){
      window.location.href = 'logout.php';
    }
  }, 1000);
})();
</script>


</body>
</html>
