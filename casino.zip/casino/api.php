<?php
declare(strict_types=1);

require __DIR__ . '/common.php';

header('Content-Type: application/json; charset=utf-8');

function json_out(int $code, array $payload): void {
  http_response_code($code);
  echo json_encode($payload, JSON_UNESCAPED_SLASHES);
  exit;
}

function ok(array $payload = []): void {
  json_out(200, array_merge(['ok'=>true], $payload));
}
function fail(int $code, string $msg): void {
  json_out($code, ['ok'=>false,'error'=>$msg]);
}

/**
 * Read JSON body (preferred) with fallback to form-encoded.
 */
$raw = file_get_contents('php://input');
$data = json_decode((string)$raw, true);
if (!is_array($data)) $data = [];
if (!$data && !empty($_POST) && is_array($_POST)) $data = $_POST;

$op   = (string)($data['op'] ?? '');
$csrf = (string)($data['csrf'] ?? '');

// CSRF check for all ops (including ping), consistent with your current approach
if ($op === '') fail(400, 'Missing op.');

if (!$csrf || !isset($_SESSION['csrf']) || !hash_equals((string)$_SESSION['csrf'], $csrf)) {
  fail(403, 'Invalid CSRF. Refresh the page.');
}

// Helper: include leaderboard if you have it, but never fatal if missing.
function maybe_leaderboard(): ?array {
  if (function_exists('lb_payload')) {
    try { return lb_payload(); } catch (Throwable $e) { return null; }
  }
  return null;
}

try {
  // ---- Keepalive / session refresh ----
  // Called by inactivity warning modal "Stay signed in"
  if ($op === 'ping') {
    ok([
      'meta' => meta_payload(),
      'ts'   => date('Y-m-d H:i:s'),
    ]);
  }

  // ---- Meta ----
  if ($op === 'meta_get') {
    ok([
      'meta' => meta_payload(),
      'csrf' => (string)$_SESSION['csrf'],
    ]);
  }

  // ---- Slots ----
  if ($op === 'slot_get') {
    ok([
      'meta' => meta_payload(),
      'slot' => slot_payload(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'slot_reset') {
    slot_reset_round();
    ok([
      'meta' => meta_payload(),
      'slot' => slot_payload(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'slot_spin') {
    $betCredits = clamp_int($data['betCredits'] ?? null, SLOT_BET_MIN, SLOT_BET_MAX);
    if ($betCredits === null) throw new Exception("Bet must be 1 or 2 credits.");
    $result = slot_play($betCredits);

    ok([
      'meta'   => meta_payload(),
      'slot'   => slot_payload(),
      'result' => $result,
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  // ---- Blackjack ----
  if ($op === 'bj_get') {
    ok([
      'meta' => meta_payload(),
      'bj'   => bj_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'bj_reset') {
    bj_reset_round();
    ok([
      'meta' => meta_payload(),
      'bj'   => bj_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'bj_start') {
    $bet = clamp_int($data['bet'] ?? null, 1, 100000000);
    if ($bet === null) throw new Exception("Invalid bet.");
    bj_start($bet);
    ok([
      'meta' => meta_payload(),
      'bj'   => bj_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'bj_hit') {
    bj_hit();
    ok(['meta'=>meta_payload(),'bj'=>bj_snapshot(),'leaderboard'=>maybe_leaderboard()]);
  }
  if ($op === 'bj_stand') {
    bj_stand();
    ok(['meta'=>meta_payload(),'bj'=>bj_snapshot(),'leaderboard'=>maybe_leaderboard()]);
  }
  if ($op === 'bj_double') {
    bj_double();
    ok(['meta'=>meta_payload(),'bj'=>bj_snapshot(),'leaderboard'=>maybe_leaderboard()]);
  }
  if ($op === 'bj_split') {
    bj_split();
    ok(['meta'=>meta_payload(),'bj'=>bj_snapshot(),'leaderboard'=>maybe_leaderboard()]);
  }
  if ($op === 'bj_insurance') {
    $amt = clamp_int($data['amt'] ?? null, 1, 100000000);
    if ($amt === null) throw new Exception("Invalid insurance amount.");
    bj_insurance($amt);
    ok(['meta'=>meta_payload(),'bj'=>bj_snapshot(),'leaderboard'=>maybe_leaderboard()]);
  }

  // ---- Baccarat ----
  if ($op === 'bac_get') {
    ok([
      'meta' => meta_payload(),
      'bac'  => bac_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'bac_reset') {
    bac_reset_round();
    ok([
      'meta' => meta_payload(),
      'bac'  => bac_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  if ($op === 'bac_deal') {
    $bet = is_array($data['bet'] ?? null) ? $data['bet'] : [];
    bac_deal($bet);
    ok([
      'meta' => meta_payload(),
      'bac'  => bac_snapshot(),
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  // ---- Global reset ----
  if ($op === 'reset_all') {
    // If you already have a canonical reset_all in common.php, call it instead.
    // This keeps behavior consistent with your earlier builds.
    if (function_exists('casino_reset_all')) {
      casino_reset_all();
    } else {
      // Fall back to session state reset
      unset($_SESSION['casino_state']);
      if (function_exists('init_state')) init_state();
    }

    ok([
      'meta' => meta_payload(),
      'slot' => function_exists('slot_payload') ? slot_payload() : null,
      'bj'   => function_exists('bj_snapshot') ? bj_snapshot() : null,
      'bac'  => function_exists('bac_snapshot') ? bac_snapshot() : null,
      'leaderboard' => maybe_leaderboard(),
    ]);
  }

  // Unknown op
  fail(400, 'Unknown op.');
} catch (Throwable $e) {
  fail(400, $e->getMessage());
}
