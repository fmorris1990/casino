<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';

session_boot();
ensure_csrf();

$msg = null;
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);
    
    $email = normalize_email(trim((string)($_POST['email'] ?? '')));
start_password_reset_email($email);


    // Generic response: do not reveal whether account exists

    $msg = "If that email is registered, a reset code was sent. Please check your inbox.";
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$csrf = csrf_token();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Forgot Password</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🔑 Reset Password</h1>
        <div class="sub">Enter your email and we’ll send a one-time reset code.</div>
      </div>
      <div class="nav">
        <a class="btn" href="login.php">Login</a>
        <a class="btn active" href="forgot.php">Forgot Password</a>
      </div>
    </div>

    <?php if ($msg): ?>
      <div class="msg" style="margin-top:12px;"><div class="ok"><?php echo htmlspecialchars($msg); ?></div></div>
      <div class="actions" style="margin-top:12px;">
        <a class="btn" href="reset.php">➡️ Enter Reset Code</a>
        <a class="btn secondary" href="login.php">Back to Login</a>
      </div>
    <?php else: ?>
      <?php if ($err): ?>
        <div class="msg" style="margin-top:12px;"><div class="err"><?php echo htmlspecialchars($err); ?></div></div>
      <?php endif; ?>

      <form method="post" class="box" style="margin-top:14px;">
        <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($csrf); ?>"/>

        <div class="small"><b>Email</b></div>
        <input name="email" type="email" autocomplete="email" required placeholder="you@example.com"
          value="<?php echo htmlspecialchars((string)($_POST['email'] ?? '')); ?>"
          style="margin-top:6px; width:100%;"/>

        <div class="actions" style="margin-top:14px;">
          <button class="btn" type="submit">📩 Send Reset Code</button>
          <a class="btn secondary" href="login.php">Cancel</a>
        </div>

        <div class="small" style="opacity:.85; margin-top:12px;">
          For your security, we don’t confirm whether an email exists in our system.
        </div>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
