<?php
declare(strict_types=1);
require __DIR__ . '/common.php';
$csrf = csrf_token();
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>High Roller Slots</title>
  <link rel="stylesheet" href="style.css"/>

  <style>
    .slotWrap{ display:grid; gap:14px; }

    .neonBar{
      border:1px solid rgba(255,255,255,.14);
      background: rgba(0,0,0,.18);
      border-radius:18px;
      padding:12px;
      display:flex;
      gap:10px;
      flex-wrap:wrap;
      align-items:center;
      justify-content:space-between;
      position:relative;
      overflow:hidden;
      box-shadow: 0 12px 30px rgba(0,0,0,.25);
    }
    .neonBar::before{
      content:'';
      position:absolute; inset:-2px;
      background: radial-gradient(circle at 20% 30%, rgba(120,220,255,.22), transparent 45%),
                  radial-gradient(circle at 80% 60%, rgba(255,120,220,.18), transparent 45%),
                  radial-gradient(circle at 40% 80%, rgba(170,255,140,.14), transparent 45%);
      filter: blur(8px);
      opacity:.8;
      pointer-events:none;
    }
    .neonLeft, .neonRight{ position:relative; z-index:2; }

    .jackpot{
      font-weight:900;
      letter-spacing:.5px;
      font-size:18px;
      text-shadow: 0 0 16px rgba(120,220,255,.25);
    }
    .jackpot small{ opacity:.85; font-weight:700; }
    .jackpotPulse{ animation: jp 1.2s ease-in-out infinite; }
    @keyframes jp { 0%,100%{ transform:scale(1);} 50%{ transform:scale(1.03);} }

    .reels{ display:flex; gap:12px; align-items:center; justify-content:center; padding:14px; }
    .reel{
      width:92px; height:92px; border-radius:18px;
      border:1px solid rgba(255,255,255,.12);
      background: rgba(0,0,0,.18);
      display:flex; align-items:center; justify-content:center;
      font-size:44px; font-weight:800;
      box-shadow: 0 10px 26px rgba(0,0,0,.25);
      position:relative;
      overflow:hidden;
    }
    .reelSpin{ animation: reelSpin 520ms linear infinite; filter: blur(.35px); }
    @keyframes reelSpin { from{ transform: translateY(0);} to{ transform: translateY(-14px);} }

    .wheelBox{ display:grid; grid-template-columns: 240px 1fr; gap:14px; align-items:center; }
    @media (max-width: 900px){ .wheelBox{ grid-template-columns: 1fr; } }

    .wheelStage{ display:flex; justify-content:center; position:relative; }
    .wheelRing{
      padding:10px;
      border-radius:999px;
      background: radial-gradient(circle at 30% 20%, rgba(120,220,255,.20), transparent 45%),
                  radial-gradient(circle at 70% 70%, rgba(255,120,220,.18), transparent 45%),
                  rgba(0,0,0,.10);
      border:1px solid rgba(255,255,255,.12);
      box-shadow: 0 14px 32px rgba(0,0,0,.28);
      position:relative;
      overflow:hidden;
    }
    .wheelRing.bonus{
      animation: vipGlow 1.05s ease-in-out infinite;
      border-color: rgba(255,210,120,.38);
    }
    @keyframes vipGlow{
      0%,100%{ box-shadow:0 0 0 0 rgba(255,210,120,.0), 0 14px 32px rgba(0,0,0,.28); }
      50%{ box-shadow:0 0 0 7px rgba(255,210,120,.12), 0 14px 32px rgba(0,0,0,.28); }
    }

    .pointer{
      width:0;height:0;
      border-left:10px solid transparent;
      border-right:10px solid transparent;
      border-bottom:18px solid rgba(255,255,255,.92);
      position:absolute; top:-2px; left:calc(50% - 10px);
      filter: drop-shadow(0 4px 8px rgba(0,0,0,.35));
      z-index:3;
    }
    .wheel{
      width:220px; height:220px; border-radius:50%;
      border:2px solid rgba(255,255,255,.20);
      background: rgba(0,0,0,.18);
      position:relative;
      overflow:hidden;
      transform: rotate(0deg);
      transition: transform 4.2s cubic-bezier(.12,.9,.08,1);
    }
    .sliceLabel{
      position:absolute; left:50%; top:50%;
      transform-origin: 0 0;
      font-weight:900;
      font-size:12px;
      opacity:.95;
      white-space:nowrap;
      text-shadow: 0 0 14px rgba(0,0,0,.35);
    }

    .paygrid{ display:grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap:10px; margin-top:10px; }
    .payitem{ border:1px solid rgba(255,255,255,.10); background: rgba(0,0,0,.15); border-radius:14px; padding:10px; }
    .payitem b{ font-size:14px; }
    .tag{ display:inline-block; padding:2px 8px; border-radius:999px; border:1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); font-size:12px; opacity:.9; margin-left:6px; }

    .bigWinOverlay{
      position:fixed; inset:0;
      display:none;
      align-items:center;
      justify-content:center;
      background: rgba(0,0,0,.62);
      backdrop-filter: blur(4px);
      z-index: 9999;
    }
    .bigWinOverlay.on{ display:flex; }
    .bigWinCard{
      width:min(560px, 92vw);
      border-radius:22px;
      padding:18px;
      border:1px solid rgba(255,255,255,.18);
      background: rgba(12,12,16,.82);
      box-shadow: 0 18px 60px rgba(0,0,0,.55);
      text-align:center;
      position:relative;
      overflow:hidden;
    }
    .bigWinCard::before{
      content:'';
      position:absolute; inset:-2px;
      background: conic-gradient(from 90deg, rgba(255,210,120,.35), rgba(255,120,220,.25), rgba(120,220,255,.22), rgba(255,210,120,.35));
      filter: blur(18px);
      opacity:.55;
      pointer-events:none;
    }
    .bigWinInner{ position:relative; z-index:2; }
    .bigTitle{ font-size:22px; font-weight:900; }
    .bigAmt{ font-size:34px; font-weight:950; margin-top:8px; }
    .bigSub{ opacity:.9; margin-top:6px; line-height:1.45; }

    .bonusBanner{
      display:none;
      margin-top:10px;
      border-radius:14px;
      padding:10px 12px;
      border:1px solid rgba(255,210,120,.30);
      background: rgba(255,210,120,.10);
      font-weight:900;
      letter-spacing:.3px;
      text-shadow: 0 0 18px rgba(255,210,120,.18);
    }
    .bonusBanner.on{ display:block; animation: bonusPulse 850ms ease-in-out infinite; }
    @keyframes bonusPulse{ 0%,100%{ transform:scale(1);} 50%{ transform:scale(1.02);} }
  </style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="top">
      <div>
        <h1>🎰 High Roller Slots</h1>
        <div class="sub">
          Two-bet VIP room: 1 credit or 2 credits. Bonus wheel is rare and <b>VIP-only</b>.
          <span class="tag" id="denomTag">—</span>
        </div>
      </div>
      <div class="nav">
        <a class="btn" href="casino.php">🏠 Hub</a>
        <a class="btn active" href="lottery.php">🎰 Slots</a>
        <a class="btn" href="blackjack.php">🂡 Blackjack</a>
        <a class="btn" href="baccarat.php">🎴 Baccarat</a>
        <a class="btn" href="tutorial.php">🎓 Tutorial</a>
        <a class="btn" href="logout.php">Logout</a>
      </div>
    </div>

    <div class="pillrow" style="margin-top:12px;">
      <div class="pill">Credits: <strong id="m-credits">—</strong></div>
      <div class="pill">Session high: <strong id="m-high">—</strong></div>
      <button class="btn" style="height:34px; padding:0 12px;" onclick="resetAll()">Reset All</button>
    </div>
  </div>

  <div class="grid">
    <div class="card">
      <div class="neonBar">
        <div class="neonLeft">
          <div class="jackpot jackpotPulse" id="jpLine">
            💰 Progressive Jackpot: <span id="jpAmt">—</span>
            <div class="small" id="jpMeta" style="margin-top:4px; opacity:.9;">—</div>
          </div>
        </div>
        <div class="neonRight">
          <button class="btn" onclick="spin(1)">Bet 1 Credit</button>
          <button class="btn" onclick="spin(2)">Bet 2 Credits (VIP)</button>
          <button class="secondary danger" onclick="roundReset()">Reset Round</button>
        </div>
      </div>

      <div id="msg" class="msg"></div>
      <div id="bonusBanner" class="bonusBanner">✨ BONUS TRIGGERED — SPINNING WHEEL…</div>

      <div class="slotWrap">
        <div class="box" style="margin-top:12px;">
          <div class="small"><b>Reels</b> <span class="small" id="metaLine"></span></div>
          <div class="reels" style="margin-top:10px;">
            <div class="reel" id="r0">—</div>
            <div class="reel" id="r1">—</div>
            <div class="reel" id="r2">—</div>
          </div>
          <div class="small" style="margin-top:10px;"><b>Result</b></div>
          <div id="status" class="small">—</div>
        </div>

        <div class="box">
          <div class="small"><b>Bonus Wheel</b> <span class="small" id="wheelHint">—</span></div>
          <div class="wheelBox" style="margin-top:10px;">
            <div class="wheelStage">
              <div class="pointer"></div>
              <div class="wheelRing" id="wheelRing">
                <div class="wheel" id="wheel"></div>
              </div>
            </div>
            <div>
              <div class="small" style="line-height:1.45;">
                <div>✅ Wheel triggers only on a <b>rare BONUS</b> (VIP bet).</div>
                <div style="margin-top:6px;">Minimum wheel payout: <b>5× wager</b>.</div>
                <div style="margin-top:6px;">Only the wheel can award the <b>progressive jackpot</b>.</div>
              </div>
              <div class="paygrid" id="paygrid"></div>
            </div>
          </div>
        </div>

        <div class="box">
          <div class="small"><b>History</b></div>
          <div class="hist" id="hist" style="margin-top:10px;"></div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2 style="margin:0; font-size:18px;">🏆 Leaderboard</h2>
      <div class="sub">Top sessions (no personal info stored).</div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>Today</b></div>
        <div id="lb-today" class="small" style="margin-top:8px;">—</div>
      </div>

      <div class="box" style="margin-top:12px;">
        <div class="small"><b>All-Time</b></div>
        <div id="lb-all" class="small" style="margin-top:8px;">—</div>
      </div>
    </div>
  </div>
</div>

<div class="bigWinOverlay" id="bigWin">
  <div class="bigWinCard">
    <div class="bigWinInner">
      <div class="bigTitle" id="bigTitle">BIG WIN!</div>
      <div class="bigAmt" id="bigAmt">—</div>
      <div class="bigSub" id="bigSub">—</div>
      <div style="margin-top:14px;">
        <button class="btn" onclick="closeBigWin()">Continue</button>
      </div>
    </div>
  </div>
</div>

<script>
const CSRF = <?php echo json_encode($csrf); ?>;

async function api(op, payload={}){
  const res = await fetch('api.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({op, csrf: CSRF, ...payload})
  });
  const data = await res.json();
  if(!res.ok || !data.ok) throw new Error(data?.error || 'Request failed');
  return data;
}

function money(n){ return String(Math.floor(Number(n||0))).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
function setMsg(type, text){
  document.getElementById('msg').innerHTML = text ? `<div class="${type==='err'?'err':'ok'}">${text}</div>` : '';
}

let SYMBOLS=null;
let WHEEL=null;
let DENOM=500;

function symEmoji(key){ return (SYMBOLS && SYMBOLS[key]) ? SYMBOLS[key][0] : String(key||''); }
function setReels(arr){
  document.getElementById('r0').textContent = arr?.[0] ? symEmoji(arr[0]) : '—';
  document.getElementById('r1').textContent = arr?.[1] ? symEmoji(arr[1]) : '—';
  document.getElementById('r2').textContent = arr?.[2] ? symEmoji(arr[2]) : '—';
}

function setSpinVisual(on){
  ['r0','r1','r2'].forEach(id=>{
    document.getElementById(id).classList.toggle('reelSpin', !!on);
  });
}

function renderMeta(m){
  document.getElementById('m-credits').textContent = money(m.credits);
  document.getElementById('m-high').textContent = money(m.sessionHighCredits ?? m.credits);
}

function renderLeaderboard(lb){
  const fmt = (e,i)=>{
    const sid = String(e.sessionId || e.userId || '----');
    return `${i+1}. +${money(e.amount)} (${sid.toString().slice(0,4)}…)`;
  };
  const today = (lb?.todayTop3 || []).map(fmt).join('<br/>') || '—';
  const all = (lb?.allTimeTop3 || []).map(fmt).join('<br/>') || '—';
  document.getElementById('lb-today').innerHTML = today;
  document.getElementById('lb-all').innerHTML = all;
}

function renderPaygrid(){
  // Wheel segments come from server; render the labels in a clean way
  if(!WHEEL?.length){
    document.getElementById('paygrid').innerHTML = `<div class="payitem"><b>—</b><div class="small">Wheel not available.</div></div>`;
    return;
  }
  const items = WHEEL.map(seg=>{
    const lab = seg.label || '—';
    const isJP = !!seg.jackpot || String(lab).toUpperCase().includes('JACKPOT');
    const desc = isJP ? 'Progressive jackpot' : `Pays ${lab} × wager`;
    return `<div class="payitem"><b>${lab}</b><div class="small">${desc}</div></div>`;
  }).join('');
  document.getElementById('paygrid').innerHTML = items;
}

function buildWheel(){
  const wheel = document.getElementById('wheel');
  wheel.innerHTML = '';
  if(!WHEEL?.length) return;

  const n = WHEEL.length;
  for(let i=0;i<n;i++){
    const seg = WHEEL[i];
    const a = (i*(360/n)) - 90;
    const lab = document.createElement('div');
    lab.className = 'sliceLabel';
    lab.textContent = seg.label;
    lab.style.transform = `rotate(${a}deg) translate(14px, -6px)`;
    wheel.appendChild(lab);
  }
}

function resetWheelVisual(){
  const ring=document.getElementById('wheelRing');
  const wheel=document.getElementById('wheel');
  ring.classList.remove('bonus');
  wheel.style.transition='none';
  wheel.style.transform='rotate(0deg)';
  void wheel.offsetWidth;
  wheel.style.transition='transform 4.2s cubic-bezier(.12,.9,.08,1)';
}

function spinWheelToIndex(idx){
  const wheel = document.getElementById('wheel');
  const ring = document.getElementById('wheelRing');
  const n = WHEEL.length;
  const per = 360/n;
  const targetCenter = idx*per + per/2;
  const spins = 6*360;
  const rot = spins + (360 - targetCenter);
  ring.classList.add('bonus');
  wheel.style.transform = `rotate(${rot}deg)`;
}

function renderJackpot(jp){
  document.getElementById('jpAmt').textContent = money(jp?.amount ?? 0);
  const last = jp?.lastWin;
  if(last && (last.amount||0) > 0){
    const who = String(last.sessionId || last.userId || '----');
    document.getElementById('jpMeta').textContent =
      `Last hit: +${money(last.amount)} • ${who.toString().slice(0,8)} • ${last.ts || ''}`;
  } else {
    document.getElementById('jpMeta').textContent = 'No jackpot hits yet.';
  }
}

function renderHistory(items){
  const el = document.getElementById('hist');
  if(!items?.length){ el.innerHTML = `<div class="histitem">No spins yet.</div>`; return; }

  el.innerHTML = items.map(it=>{
    const r = (it.reels||[]).map(symEmoji).join(' ');
    const wager = it.wager || (it.betCredits*it.denom);
    const base = it.baseProfit>0 ? `Base +${money(it.baseProfit)}` : `No hit`;
    const jp = it.jackpotHit ? ` • JACKPOT +${money(it.jackpotAward)}` : '';
    const wheel = it.wheel
      ? (it.wheel.jackpot ? ` • Wheel JACKPOT` : ` • Wheel ${it.wheel.label} → +${money(it.wheel.bonus||0)}`)
      : '';
    const bonus = it.bonusTriggered ? ` <span class="tag">BONUS</span>` : '';
    const vip = it.vip ? ` <span class="tag">VIP</span>` : '';
    return `
      <div class="histitem">
        <div><b>${base}${wheel}${jp}</b>${vip}${bonus} <span class="small">• ${it.time}</span></div>
        <div class="small">Bet ${it.betCredits}c (${money(wager)}) • ${r} • Credits ${money(it.before)} → ${money(it.after)}</div>
      </div>
    `;
  }).join('');
}

function openBigWin(title, amt, sub){
  document.getElementById('bigTitle').textContent = title;
  document.getElementById('bigAmt').textContent = amt;
  document.getElementById('bigSub').textContent = sub;
  document.getElementById('bigWin').classList.add('on');
}
function closeBigWin(){
  document.getElementById('bigWin').classList.remove('on');
}

function setBonusBanner(on){
  document.getElementById('bonusBanner').classList.toggle('on', !!on);
}

async function load(){
  const d = await api('slot_get');
  renderMeta(d.meta);
  renderLeaderboard(d.leaderboard);

  SYMBOLS = d.slot.symbols;
  WHEEL = d.slot.wheel;
  DENOM = d.slot.denom || 500;

  document.getElementById('denomTag').textContent = `1c = ${money(DENOM)} • VIP bet = ${money(DENOM*2)}`;
  buildWheel();
  renderPaygrid();

  renderJackpot(d.slot.jackpot);

  const last = d.slot.last;
  if(last?.reels) setReels(last.reels);
  renderHistory(d.slot.history || []);

  document.getElementById('wheelHint').textContent = 'Wheel spins only on rare BONUS (VIP bet).';
}

async function spin(betCredits){
  setMsg('', '');
  setBonusBanner(false);
  setSpinVisual(true);
  resetWheelVisual();

  // quick reel spin feel
  await new Promise(r=>setTimeout(r, 650));

  try{
    const d = await api('slot_spin', {betCredits});
    renderMeta(d.meta);
    renderLeaderboard(d.leaderboard);

    renderJackpot(d.slot.jackpot);

    const result = d.result;
    setReels(result.reels);

    const wager = result.wager || (result.betCredits*result.denom);
    document.getElementById('metaLine').textContent =
      `• Bet ${result.betCredits}c (${money(wager)}) • Credits ${money(result.before)} → ${money(result.after)}`;

    let line = (result.baseProfit>0) ? `Reels won +${money(result.baseProfit)}.` : `No reel win.`;
    if(result.jpInc) line += ` Jackpot +${money(result.jpInc)}.`;
    if(result.bonusTriggered) line += ` BONUS TRIGGERED!`;
    document.getElementById('status').textContent = line;

    // BONUS -> wheel
    const hint = document.getElementById('wheelHint');
    if(result.bonusTriggered && result.wheel && WHEEL?.length){
      setBonusBanner(true);
      hint.textContent = 'BONUS — spinning the wheel…';

      // spin animation to returned index
      setTimeout(()=> spinWheelToIndex(result.wheel.index), 60);

      setTimeout(()=>{
        // jackpot slice
        if(result.wheel.jackpot || result.jackpotHit){
          hint.textContent = `Wheel: JACKPOT! +${money(result.jackpotAward)}`;
          openBigWin(
            '💰 JACKPOT HIT!',
            `+${money(result.jackpotAward)}`,
            `Progressive resets after hit.`
          );
        } else {
          const wb = Number(result.wheel.bonus || 0);
          hint.textContent = `Wheel: ${result.wheel.label} • +${money(wb)}`;
          if(wb > 0){
            openBigWin('✨ BONUS WIN!', `+${money(wb)}`, `${result.wheel.label} × wager`);
          }
        }
        setBonusBanner(false);
      }, 4300);

    } else {
      hint.textContent = 'Wheel spins only on rare BONUS (VIP bet).';
    }

    renderHistory(d.slot.history || []);
    setMsg('ok', 'Spin complete.');
  } catch(e){
    setMsg('err', e.message);
  } finally {
    setSpinVisual(false);
  }
}

async function roundReset(){
  setMsg('', '');
  setBonusBanner(false);
  try{
    const d = await api('slot_reset');
    renderMeta(d.meta);
    renderLeaderboard(d.leaderboard);
    renderJackpot(d.slot.jackpot);

    document.getElementById('status').textContent = '—';
    document.getElementById('metaLine').textContent = '';
    document.getElementById('wheelHint').textContent = 'Wheel spins only on rare BONUS (VIP bet).';
    resetWheelVisual();

    setMsg('ok','Round reset.');
  } catch(e){
    setMsg('err', e.message);
  }
}

async function resetAll(){
  if(!confirm('Reset all stats/credits?')) return;
  const r=await api('reset_all');
  renderMeta(r.meta);
  renderLeaderboard(r.leaderboard);

  SYMBOLS = r.slot.symbols;
  WHEEL = r.slot.wheel;
  DENOM = r.slot.denom || 500;

  document.getElementById('denomTag').textContent = `1c = ${money(DENOM)} • VIP bet = ${money(DENOM*2)}`;
  buildWheel();
  renderPaygrid();

  renderJackpot(r.slot.jackpot);

  setReels(r.slot.last?.reels || null);
  renderHistory(r.slot.history || []);

  setMsg('ok','Reset complete.');
}

load().catch(e=>alert(e.message));
</script>

<script>
(function(){
  const IDLE_LIMIT_MS = 20 * 60 * 1000;   // 20 minutes total
  const WARN_AT_MS    = 18 * 60 * 1000;   // warn at 18 minutes
  let tLast = Date.now();
  let warned = false;

  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position:fixed; inset:0; display:none; align-items:center; justify-content:center;
    background:rgba(0,0,0,.55); backdrop-filter: blur(4px); z-index:99999;
  `;
  overlay.innerHTML = `
    <div style="width:min(520px,92vw); border-radius:18px; border:1px solid rgba(255,255,255,.18);
      background:rgba(12,12,16,.88); padding:16px; box-shadow:0 18px 60px rgba(0,0,0,.55);">
      <div style="font-weight:900; font-size:18px;">You’re about to be signed out</div>
      <div style="opacity:.9; margin-top:8px; line-height:1.45;">
        For your security, we log you out after inactivity. Click below to stay signed in.
      </div>
      <div style="margin-top:14px; display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;">
        <button id="stayBtn" class="btn">Stay signed in</button>
        <a class="btn secondary" href="logout.php">Logout now</a>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  function touch(){ tLast = Date.now(); warned = false; overlay.style.display='none'; }
  ['click','keydown','mousemove','touchstart','scroll'].forEach(ev => window.addEventListener(ev, touch, {passive:true}));

  // This pings server to refresh session timer (you’ll add api op=ping in api.php)
  async function ping(){
    try{
      if (typeof CSRF === 'undefined') return touch();
      await fetch('api.php', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({op:'ping', csrf: CSRF})
      });
    } catch(e) {}
    touch();
  }
  overlay.querySelector('#stayBtn').addEventListener('click', ping);

  setInterval(()=>{
    const idle = Date.now() - tLast;
    if (!warned && idle >= WARN_AT_MS && idle < IDLE_LIMIT_MS){
      warned = true;
      overlay.style.display='flex';
    }
    if (idle >= IDLE_LIMIT_MS){
      window.location.href = 'logout.php';
    }
  }, 1000);
})();
</script>


</body>
</html>
