<?php
declare(strict_types=1);
ini_set('display_errors','1');
ini_set('display_startup_errors','1');
error_reporting(E_ALL);

echo "PHP OK<br/>";

require __DIR__ . '/auth.php';
echo "auth.php OK<br/>";

require __DIR__ . '/common.php';
echo "common.php OK<br/>";

echo "Session user: ";
var_dump(current_user());

echo "<br/>Calling meta_payload...<br/>";
var_dump(meta_payload());

echo "<br/>DONE<br/>";
