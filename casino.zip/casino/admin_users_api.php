<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/security.php';

require_admin();

header('Content-Type: application/json; charset=utf-8');

function json_out(int $code, array $payload): void {
  http_response_code($code);
  echo json_encode($payload, JSON_UNESCAPED_SLASHES);
  exit;
}

$raw = file_get_contents('php://input');
$data = json_decode((string)$raw, true);
if (!is_array($data)) $data = [];

try {
  csrf_check((string)($data['csrf'] ?? ''));

  $op = (string)($data['op'] ?? '');
  $pdo = db();

  if ($op === 'users_list') {
    $q = trim((string)($data['q'] ?? ''));
    $filter = (string)($data['filter'] ?? 'all');

    $where = [];
    $args = [];

    if ($q !== '') {
      $where[] = "email LIKE ?";
      $args[] = "%{$q}%";
    }

    if ($filter === 'active') $where[] = "is_banned = 0";
    if ($filter === 'banned') $where[] = "is_banned = 1";
    if ($filter === 'admins') $where[] = "is_admin = 1";

    $sql = "SELECT id, email, credits, start_credits, session_high_credits, total_wagered, total_won, is_admin, is_banned, created_at
            FROM users";
    if ($where) $sql .= " WHERE " . implode(" AND ", $where);
    $sql .= " ORDER BY id DESC LIMIT 200";

    $st = $pdo->prepare($sql);
    $st->execute($args);
    $users = $st->fetchAll() ?: [];

    json_out(200, ['ok'=>true, 'users'=>$users]);
  }

  if ($op === 'user_adjust_credits') {
    $userId = clamp_int($data['userId'] ?? null, 1, 2000000000);
    if ($userId === null) throw new Exception("Invalid userId.");

    $delta = filter_var($data['delta'] ?? null, FILTER_VALIDATE_INT);
    if ($delta === false || (int)$delta === 0) throw new Exception("Invalid delta.");

    // Don’t allow negative resulting credits
    $pdo->beginTransaction();
    try {
      $st = $pdo->prepare("SELECT credits FROM users WHERE id=? FOR UPDATE");
      $st->execute([$userId]);
      $row = $st->fetch();
      if (!$row) throw new Exception("User not found.");

      $cur = (int)$row['credits'];
      $next = $cur + (int)$delta;
      if ($next < 0) throw new Exception("Cannot reduce below 0 credits.");

      $pdo->prepare("UPDATE users SET credits=?, updated_at=NOW() WHERE id=?")->execute([$next, $userId]);

      // update session high if increased
      $pdo->prepare("UPDATE users SET session_high_credits = GREATEST(session_high_credits, credits) WHERE id=?")
          ->execute([$userId]);

      $pdo->commit();
    } catch (Throwable $e) {
      $pdo->rollBack();
      throw $e;
    }

    $st = $pdo->prepare("SELECT id, email, credits, is_admin, is_banned FROM users WHERE id=?");
    $st->execute([$userId]);
    $u = $st->fetch();
    json_out(200, ['ok'=>true, 'user'=>$u]);
  }

  if ($op === 'user_set_banned') {
    $userId = clamp_int($data['userId'] ?? null, 1, 2000000000);
    if ($userId === null) throw new Exception("Invalid userId.");
    $banned = !empty($data['banned']) ? 1 : 0;

    $pdo->prepare("UPDATE users SET is_banned=?, updated_at=NOW() WHERE id=?")->execute([$banned, $userId]);
    json_out(200, ['ok'=>true]);
  }

  if ($op === 'user_set_admin') {
    $userId = clamp_int($data['userId'] ?? null, 1, 2000000000);
    if ($userId === null) throw new Exception("Invalid userId.");
    $isAdmin = !empty($data['isAdmin']) ? 1 : 0;

    // Optional safety: ensure you don't remove the last admin
    if ($isAdmin === 0) {
      $st = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE is_admin=1");
      $st->execute();
      $count = (int)($st->fetch()['c'] ?? 0);

      $st2 = $pdo->prepare("SELECT is_admin FROM users WHERE id=?");
      $st2->execute([$userId]);
      $row = $st2->fetch();
      if ($row && (int)$row['is_admin'] === 1 && $count <= 1) {
        throw new Exception("Cannot remove the last admin.");
      }
    }

    $pdo->prepare("UPDATE users SET is_admin=?, updated_at=NOW() WHERE id=?")->execute([$isAdmin, $userId]);
    json_out(200, ['ok'=>true]);
  }

  json_out(400, ['ok'=>false, 'error'=>'Unknown op.']);
} catch (Throwable $e) {
  json_out(400, ['ok'=>false, 'error'=>$e->getMessage()]);
}
